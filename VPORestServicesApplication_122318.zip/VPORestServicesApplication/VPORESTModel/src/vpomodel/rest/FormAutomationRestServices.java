package vpomodel.rest;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import oracle.jbo.ApplicationModule;
import oracle.jbo.Row;
import oracle.jbo.ViewObject;
import oracle.jbo.client.Configuration;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


@Path("formautomation")
@Consumes("application/json")
@Produces("application/json")
public class FormAutomationRestServices {
    private static final String amDef = "vpomodel.eo.AppModule";
    private static final String config = "AppModuleLocal";

    public FormAutomationRestServices() {
        super();
    }


    @GET
    @Path("/countryCode")
    public String getCountryCode(@QueryParam("personnelIdVal") String personnelId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("CountryCodeLOV1");
                vo.setNamedWhereClauseParam("in_personnel3", personnelId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("countryCode", row.getAttribute("Value").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("countryCode", "");
                        }

                        try {
                            jsonObjectR3.put("countryCodeId", row.getAttribute("Value").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("countryCodeId", "");
                        }

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("countryCode", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/siteListForUser")
    public String getSiteListForUser(@QueryParam("personnelIdVal") String personnelId,
                                     @QueryParam("countryIdVal") String countryId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("SiteListForUser1");
                vo.setNamedWhereClauseParam("in_personnel1", personnelId);
                vo.setNamedWhereClauseParam("in_countryCode", countryId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("studysiteid", row.getAttribute("Value").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("studysiteid", "");
                        }

                        try {
                            jsonObjectR3.put("studysite", row.getAttribute("Value").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("studysite", "");
                        }


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("studySiteCode", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/trialsForSite")
    public String getTrialsForSite(@QueryParam("personnelIdVal") String personnelId,
                                   @QueryParam("countryIdVal") String countryId,
                                   @QueryParam("studyIdVal") String studyId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("TrialsForSite1");
                vo.setNamedWhereClauseParam("in_studySite1", studyId);
                vo.setNamedWhereClauseParam("in_personnel2", personnelId);
                vo.setNamedWhereClauseParam("in_countryCode3", countryId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();

                        try {
                            jsonObjectR3.put("trialCode", row.getAttribute("StudyCodeAlias").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("trialCode", "");
                        }

                        try {
                            jsonObjectR3.put("trialId", row.getAttribute("StudySiteEid").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("trialId", "");
                        }

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("trialCode", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/allVendors")
    public String getAllVendorCategories() {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("AllVendorCategories1");
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("vendorCategoryId", row.getAttribute("VendorCategoryId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorCategoryId", "");
                        }
                        try {
                            jsonObjectR3.put("vendorCategoryName", row.getAttribute("VendorCategoryName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorCategoryName", "");
                        }


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("vendorCategory", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/vendorForCategory")
    public String getVendorsForCategory(@QueryParam("categoryIdVal") String categoryId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("VendorsForCategory1");
                vo.setNamedWhereClauseParam("in_vendorCategoryId", categoryId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("vendorId", row.getAttribute("VendorId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorId", "");
                        }
                        try {
                            jsonObjectR3.put("vendorName", row.getAttribute("VendorName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorName", "");
                        }


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("vendorCategory", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/formListing")
    public String getFormListing(@QueryParam("personnelIdVal") String personnelId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("FormListingMO2_1");
                vo.setNamedWhereClauseParam("fl_personnelId", personnelId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("formId", row.getAttribute("FormId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formId", "");
                        }
                        try {
                            jsonObjectR3.put("formName", row.getAttribute("FormName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formName", "");
                        }

                        try {
                            jsonObjectR3.put("submissionDueDate", row.getAttribute("SubmissionDueDate").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("submissionDueDate", "");
                        }
                        try {
                            jsonObjectR3.put("status", row.getAttribute("Status").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("status", "");
                        }
                        try {
                            jsonObjectR3.put("updatedDate", row.getAttribute("UpdatedDate").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("updatedDate", "");
                        }
                        try {
                            jsonObjectR3.put("vendorCategoryMappingId",
                                             row.getAttribute("VendorCategoryMappingId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorCategoryMappingId", "");
                        }
                        try {
                            jsonObjectR3.put("vendorCategoryId", row.getAttribute("VendorCategoryId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorCategoryId", "");
                        }
                        try {
                            jsonObjectR3.put("vendorCategoryName", row.getAttribute("VendorCategoryName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorCategoryName", "");
                        }

                        try {
                            jsonObjectR3.put("vendorId", row.getAttribute("VendorId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorId", "");
                        }

                        try {
                            jsonObjectR3.put("vendorName", row.getAttribute("VendorName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorName", "");
                        }

                        try {
                            jsonObjectR3.put("studySiteIdVpo", row.getAttribute("StudySiteIdVpo").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("studySiteIdVpo", "");
                        }

                        try {
                            jsonObjectR3.put("studyCodeAlias", row.getAttribute("StudyCodeAlias").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("studyCodeAlias", "");
                        }

                        try {
                            jsonObjectR3.put("studySiteId", row.getAttribute("StudySiteId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("studySiteId", "");
                        }

                        try {
                            jsonObjectR3.put("investigatorName", row.getAttribute("InvestigatorName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("investigatorName", "");
                        }


                        try {
                            jsonObjectR3.put("formFinalizedDate", row.getAttribute("FormFinalizedDate").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formFinalizedDate", "");
                        }

                        try {
                            jsonObjectR3.put("formVersion", row.getAttribute("FormVersion").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formVersion", "");
                        }

                        try {
                            jsonObjectR3.put("countryCode", row.getAttribute("CountryCode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("countryCode", "");
                        }

                        try {
                            jsonObjectR3.put("studySiteEid", row.getAttribute("StudySiteEid").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("studySiteEid", "");
                        }

                        try {
                            jsonObjectR3.put("requestReceivedDate", row.getAttribute("RequestReceivedDate").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("requestReceivedDate", "");
                        }


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("countryCode", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/validateForm")
    public String validateFormForUser(@QueryParam("personnelIdVal") String personnelId,
                                      @QueryParam("regionIdVal") String regionId,
                                      @QueryParam("siteIdVal") String siteId,
                                      @QueryParam("studyCodeVal") String trailCode,
                                      @QueryParam("categoryIdVal") String vendorCategoryId,
                                      @QueryParam("vendorIdval") String vendorId,
                                      @QueryParam("statusVal") String status) {
        JSONObject jsonObjectR = new JSONObject();

        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("ValidateFormForUserMO1");
                vo.setNamedWhereClauseParam("validatePersonnelId1", personnelId);
                // vo.setNamedWhereClauseParam("validateRegionId1", regionId);
                vo.setNamedWhereClauseParam("validateSiteId1", siteId);
                vo.setNamedWhereClauseParam("validateTrailCode1", trailCode);
                vo.setNamedWhereClauseParam("validateVendorCategoryId1", vendorCategoryId);
                vo.setNamedWhereClauseParam("validateVendorId1", vendorId);
                vo.setNamedWhereClauseParam("validateStatus1", status);
                vo.executeQuery();

                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        try {
                            jsonObjectR.put("formId", row.getAttribute("FormId").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("formId", "0");
                        }

                        try {
                            jsonObjectR.put("vendorCategoryMappingId",
                                            row.getAttribute("VendorCategoryMappingId").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("vendorCategoryMappingId", "");
                        }

                        try {
                            jsonObjectR.put("studySiteIdVpo", row.getAttribute("StudySiteIdVpo").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("studySiteIdVpo", "");
                        }

                        try {
                            jsonObjectR.put("personnelId", row.getAttribute("PersonnelId").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("personnelId", "");
                        }

                        try {
                            jsonObjectR.put("formName", row.getAttribute("AsFormName").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("formName", "");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                e.printStackTrace();
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/fetchFormData")
    public String fetchFormData(@QueryParam("formIdVal") String formId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("FetchFormData1");
                vo.setNamedWhereClauseParam("fetchFormId", formId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("formId", row.getAttribute("FormId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formId", "");
                        }
                        try {
                            jsonObjectR3.put("formDetails", row.getAttribute("FormDetails").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formDetails", "");
                        }
                        try {
                            jsonObjectR3.put("formDetailsId", row.getAttribute("FormDetailsId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formDetailsId", "");
                        }

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("formData", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/formTrialsDetails")
    public String formTrialDetails(@QueryParam("personnelIdVal") String personnelId,
                                   @QueryParam("countryCodeVal") String countryCode,
                                   @QueryParam("siteIdVal") String siteId, @QueryParam("studyCodeVal") String studyCode,
                                   @QueryParam("prefixVal") String prefix) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        if (prefix == null || prefix == "") {
            prefix = "CL";
        }
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("FormTrialsDetails1");
                vo.setNamedWhereClauseParam("trialDetailsCountryCode", countryCode);
                vo.setNamedWhereClauseParam("trialDetailsPersonnelId", personnelId);
                vo.setNamedWhereClauseParam("trialDetailsSiteId", siteId);
                vo.setNamedWhereClauseParam("trialDetailsStudyCode", studyCode);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put(prefix + "SponsorName", "NOVARTIS");
                            //jsonObjectR3.put(prefix + "SponsorName", row.getAttribute("StudySiteEref").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SponsorName", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "TrialCode", row.getAttribute("StudyCodeAlias").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "TrialCode", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "SiteId", row.getAttribute("StudySiteId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SiteId", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "ProjectCode", row.getAttribute("ProjectCodeAlias").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "ProjectCode", "");
                        }


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("trialDetails", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/formCenter")
    public String formCenter(@QueryParam("stateCodeVal") String stateCode,
                             @QueryParam("countryCodeVal") String countryCode,
                             @QueryParam("studyRefVal") String studyRef, @QueryParam("prefixVal") String prefix) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        if (prefix == null || prefix == "") {
            prefix = "CL";
        }
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("FormCenter1");
                vo.setNamedWhereClauseParam("centerCountryCode", countryCode);
                vo.setNamedWhereClauseParam("centerStudyRef", studyRef);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put(prefix + "ZipCode",
                                             row.getAttribute("PostalAddressPostalCode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "ZipCode", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "CenterType", row.getAttribute("CenterTypeDesc").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "CenterType", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "CentreStreetAddress",
                                             row.getAttribute("PostalAddressLines").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "CentreStreetAddress", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "City", row.getAttribute("PostalAddressCityName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "City", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "State", row.getAttribute("PostalAddressStateName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "State", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "Country",
                                             row.getAttribute("PostalAddressCountryName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "Country", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "Department", row.getAttribute("StudySiteEid").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "Department", "");
                        }


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("center", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/formInvestigator")
    public String formInvestigator(@QueryParam("regionIdVal") String RegionId,
                                   @QueryParam("countryCodeVal") String countryCode,
                                   @QueryParam("siteIdVal") String siteId, @QueryParam("studyCodeVal") String studyCode,
                                   @QueryParam("prefixVal") String prefix) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        if (prefix == null || prefix == "") {
            prefix = "CL";
        }
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("FormInvestigatorMO1");
                vo.setNamedWhereClauseParam("centerCountryCode", countryCode);
                vo.setNamedWhereClauseParam("centerRegionId", RegionId);
                vo.setNamedWhereClauseParam("centerSiteId", siteId);
                vo.setNamedWhereClauseParam("centerStudyCode", studyCode);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put(prefix + "RoleName", row.getAttribute("RoleAtSiteLvlCode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "RoleName", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "roleAtSiteLvlCode",
                                             row.getAttribute("RoleAtSiteLvlCode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "roleAtSiteLvlCode", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "Title", row.getAttribute("Title").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "Title", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "FirstName", row.getAttribute("Forename").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "FirstName", "");
                        }

                        //                        try {
                        //                            jsonObjectR3.put(prefix + "MiddleName", row.getAttribute("MiddleName").toString());
                        //                        } catch (Exception e) {
                        //                            jsonObjectR3.put(prefix + "MiddleName", "");
                        //                        }

                        try {
                            jsonObjectR3.put(prefix + "LastName", row.getAttribute("Surname").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "LastName", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "PhoneCode", row.getAttribute("Phone").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "PhoneCode", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "EmailAddress", row.getAttribute("EmailAddress").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "EmailAddress", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "FaxNumber", row.getAttribute("Fax").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "FaxNumber", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "postalAddressLines",
                                             row.getAttribute("PostalAddressLines").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "PostalAddressLines", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "postalAddressStateName",
                                             row.getAttribute("PostalAddressStateName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "postalAddressStateName", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "postalAddressPostalCode",
                                             row.getAttribute("PostalAddressPostalCode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "postalAddressPostalCode", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "postalAddressCityName",
                                             row.getAttribute("PostalAddressCityName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "PostalAddressCityName", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "postalAddressCountryName",
                                             row.getAttribute("PostalAddressCountryName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "postalAddressCountryName", "");
                        }


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("Investigator", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/secondaryContact")
    public String formSecondaryContact(@QueryParam("regionIdVal") String regionId,
                                       @QueryParam("countryCodeVal") String countryCode,
                                       @QueryParam("siteIdVal") String siteId,
                                       @QueryParam("studyCodeVal") String studyCode,
                                       @QueryParam("prefixVal") String prefix) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        if (prefix == null || prefix == "") {
            prefix = "CL";
        }
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("FormSecondaryContactMO2");
                vo.setNamedWhereClauseParam("secondaryCountryCode", countryCode);
                vo.setNamedWhereClauseParam("secondaryRegionId", regionId);
                vo.setNamedWhereClauseParam("secondarySiteId", siteId);
                vo.setNamedWhereClauseParam("secondaryStudyCode", studyCode);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("roleAtSiteLvlDesc", row.getAttribute("RoleAtSiteLvlDesc").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("roleAtSiteLvlDesc", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "roleAtSiteLvlCode",
                                             row.getAttribute("RoleAtSiteLvlCode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "roleAtSiteLvlCode", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "SecondatyTitle", row.getAttribute("Title").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SecondatyTitle", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "SecondaryFirstName", row.getAttribute("Forename").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SecondaryFirstName", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "SecondaryMiddleName", "");
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SecondaryMiddleName", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "SecondaryLastName", row.getAttribute("Surname").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SecondaryLastName", "");
                        }


                        try {
                            jsonObjectR3.put(prefix + "SecondaryPhoneCode", row.getAttribute("Phone").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SecondaryPhoneCode", "");
                        }


                        try {
                            jsonObjectR3.put(prefix + "SecondaryFaxNumber", row.getAttribute("Fax").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SecondaryFaxNumber", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "SecondaryEmailAddress",
                                             row.getAttribute("EmailAddress").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SecondaryEmailAddress", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "postalAddressLines",
                                             row.getAttribute("PostalAddressLines").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "postalAddressLines", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "postalAddressStateName",
                                             row.getAttribute("PostalAddressStateName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "postalAddressStateName", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "postalAddressPostalCode",
                                             row.getAttribute("PostalAddressPostalCode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "postalAddressPostalCode", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "postalAddressCityName",
                                             row.getAttribute("PostalAddressCityName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "postalAddressCityName", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "postalAddressCountryName",
                                             row.getAttribute("PostalAddressCountryName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "postalAddressCountryName", "");
                        }

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("secondaryContact", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/getVersionHistory")
    public String formGetVersionHistory(@QueryParam("categoryIdVal") String categoryId,
                                        @QueryParam("countryCodeVal") String countryCode,
                                        @QueryParam("siteIdVal") String siteId,
                                        @QueryParam("studyCodeVal") String studyCode,
                                        @QueryParam("personnelIdVal") String personnelId,
                                        @QueryParam("vendorIdVal") String vendorId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("FormVersionHistory1");
                vo.setNamedWhereClauseParam("historyCategoryId", categoryId);
                vo.setNamedWhereClauseParam("historyCountryCode", countryCode);
                vo.setNamedWhereClauseParam("historyPersonnelId", personnelId);
                vo.setNamedWhereClauseParam("historyStudyCode", studyCode);
                vo.setNamedWhereClauseParam("historyStudySiteId", siteId);
                vo.setNamedWhereClauseParam("historyVendorId", vendorId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("formId", row.getAttribute("FormId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formId", "");
                        }
                        try {
                            jsonObjectR3.put("formVersion", row.getAttribute("FormVersion").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formVersion", "");
                        }

                        try {
                            jsonObjectR3.put("updatedBy", row.getAttribute("UpdatedBy").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("updatedBy", "");
                        }

                        try {
                            jsonObjectR3.put("updatedDate", row.getAttribute("UpdatedDate").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("updatedDate", "");
                        }

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("versionHistory", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }

    @GET
    @Path("/ReleaseLock")
    public String getVendorsReleaseLock(@QueryParam("SiteRefVal") String siteRef,
                                        @QueryParam("VendorCategoryIdVAL") String vendorCategoryId,
                                        @QueryParam("VendorIdVal") String vendorId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("ReleaseLock1");
                vo.setNamedWhereClauseParam("siteRef", siteRef);
                vo.setNamedWhereClauseParam("vendorCategoryId", vendorCategoryId);
                vo.setNamedWhereClauseParam("vendorId", vendorId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("formId", row.getAttribute("FormId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formId", "");
                        }


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("vendorCategory", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }

    @GET
    @Path("/personalDetailsECG")
    public String getECGPersonalDetails(@QueryParam("studycodeVal") String StudycodeAlias1,
                                        @QueryParam("countryIdval") String countryCode,
                                        @QueryParam("studySiteIdVal") String studySiteId,
                                        @QueryParam("prefixVal") String prefix) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("personalInfoEcg1");
                vo.setNamedWhereClauseParam("StudycodeAlias1", StudycodeAlias1);
                vo.setNamedWhereClauseParam("countryCode", countryCode);
                vo.setNamedWhereClauseParam("studySiteId", studySiteId);
                vo.setNamedWhereClauseParam("roleofInvestigator", "('PINV','CRA', 'SC')");
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        String roleDesc = row.getAttribute("RoleAtSiteLvlCode").toString();

                        if (roleDesc.equalsIgnoreCase("PINV")) {
                            try {
                                jsonObjectR3.put(prefix + "PI" + "Title", row.getAttribute("Title").toString());
                            } catch (Exception e) {
                                jsonObjectR3.put(prefix + "PI" + "Title", "");
                            }
                            try {
                                jsonObjectR3.put(prefix + "PI" + "LastName", row.getAttribute("Forename").toString());
                            } catch (Exception e) {
                                jsonObjectR3.put(prefix + "PI" + "LastName", "");
                            }
                            try {
                                jsonObjectR3.put(prefix + "PI" + "middleName",
                                                 row.getAttribute("MiddleName").toString());
                            } catch (Exception e) {
                                jsonObjectR3.put(prefix + "PI" + "middleName", "");
                            }
                            try {
                                jsonObjectR3.put(prefix + "PI" + "FirstName", row.getAttribute("Surname").toString());
                            } catch (Exception e) {
                                jsonObjectR3.put(prefix + "PI" + "FirstName", "");
                            }
                            try {
                                jsonObjectR3.put(prefix + "PI" + "Phone", row.getAttribute("PhoneAddress").toString());
                            } catch (Exception e) {
                                jsonObjectR3.put(prefix + "PI" + "Phone", "");
                            }
                            try {
                                jsonObjectR3.put(prefix + "PI" + "Fax", row.getAttribute("FaxAddress").toString());
                            } catch (Exception e) {
                                jsonObjectR3.put(prefix + "PI" + "Fax", "");
                            }
                            try {
                                jsonObjectR3.put(prefix + "PI" + "Email", row.getAttribute("EmailAddress").toString());
                            } catch (Exception e) {
                                jsonObjectR3.put(prefix + "PI" + "Email", "");
                            }


                        } else if (roleDesc.equalsIgnoreCase("CRA")) {


                            try {
                                jsonObjectR3.put(prefix + "CRA" + "Title", row.getAttribute("Title").toString());
                            } catch (Exception e) {
                                jsonObjectR3.put(prefix + "CRA" + "Title", "");
                            }
                            try {
                                jsonObjectR3.put(prefix + "CRA" + "LastName", row.getAttribute("Forename").toString());
                            } catch (Exception e) {
                                jsonObjectR3.put(prefix + "CRA" + "LastName", "");
                            }
                            try {
                                jsonObjectR3.put(prefix + "CRA" + "middleName",
                                                 row.getAttribute("MiddleName").toString());
                            } catch (Exception e) {
                                jsonObjectR3.put(prefix + "CRA" + "middleName", "");
                            }
                            try {
                                jsonObjectR3.put(prefix + "CRA" + "FirstName", row.getAttribute("Surname").toString());
                            } catch (Exception e) {
                                jsonObjectR3.put(prefix + "CRA" + "FirstName", "");
                            }
                            try {
                                jsonObjectR3.put(prefix + "CRA" + "Phone", row.getAttribute("PhoneAddress").toString());
                            } catch (Exception e) {
                                jsonObjectR3.put(prefix + "CRA" + "Phone", "");
                            }
                            try {
                                jsonObjectR3.put(prefix + "CRA" + "Fax", row.getAttribute("FaxAddress").toString());
                            } catch (Exception e) {
                                jsonObjectR3.put(prefix + "CRA" + "Fax", "");
                            }
                            try {
                                jsonObjectR3.put(prefix + "CRA" + "Email", row.getAttribute("EmailAddress").toString());
                            } catch (Exception e) {
                                jsonObjectR3.put(prefix + "CRA" + "Email", "");
                            }


                        } else if (roleDesc.equalsIgnoreCase("TC")) {

                            try {
                                jsonObjectR3.put(prefix + "SC" + "Title", row.getAttribute("Title").toString());
                            } catch (Exception e) {
                                jsonObjectR3.put(prefix + "SC" + "Title", "");
                            }
                            try {
                                jsonObjectR3.put(prefix + "SC" + "LastName", row.getAttribute("Forename").toString());
                            } catch (Exception e) {
                                jsonObjectR3.put(prefix + "SC" + "LastName", "");
                            }
                            try {
                                jsonObjectR3.put(prefix + "SC" + "middleName",
                                                 row.getAttribute("MiddleName").toString());
                            } catch (Exception e) {
                                jsonObjectR3.put(prefix + "SC" + "middleName", "");
                            }
                            try {
                                jsonObjectR3.put(prefix + "SC" + "FirstName", row.getAttribute("Surname").toString());
                            } catch (Exception e) {
                                jsonObjectR3.put(prefix + "SC" + "FirstName", "");
                            }
                            try {
                                jsonObjectR3.put(prefix + "SC" + "Phone", row.getAttribute("PhoneAddress").toString());
                            } catch (Exception e) {
                                jsonObjectR3.put(prefix + "SC" + "Phone", "");
                            }
                            try {
                                jsonObjectR3.put(prefix + "SC" + "Fax", row.getAttribute("FaxAddress").toString());
                            } catch (Exception e) {
                                jsonObjectR3.put(prefix + "SC" + "Fax", "");
                            }
                            try {
                                jsonObjectR3.put(prefix + "SC" + "Email", row.getAttribute("EmailAddress").toString());
                            } catch (Exception e) {
                                jsonObjectR3.put(prefix + "SC" + "Email", "");
                            }


                        }

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("trialCode", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }

    @GET
    @Path("/siteDetails")
    public String getECGsiteDetails(@QueryParam("countryCodeVal") String centerCountryCode,
                                    @QueryParam("StateCodeVal") String centerStateCode1,
                                    @QueryParam("studyRef1Val") String centerStudyRef1,
                                    @QueryParam("trailDetailsStudyCodeVal") String trialDetailsStudyCode) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("SiteInfoEcg1");
                vo.setNamedWhereClauseParam("centerCountryCode", centerCountryCode);
                vo.setNamedWhereClauseParam("centerStateCode1", centerStateCode1);
                vo.setNamedWhereClauseParam("centerStudyRef1", centerStudyRef1);
                vo.setNamedWhereClauseParam("trialDetailsStudyCode", trialDetailsStudyCode);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("studyCodeAlias", row.getAttribute("StudyCodeAlias").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("studyCodeAlias", "");
                        }
                        try {
                            jsonObjectR3.put("projectCodeAlias", row.getAttribute("ProjectCodeAlias").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("projectCodeAlias", "");
                        }
                        try {
                            jsonObjectR3.put("postalAddressPostalCode",
                                             row.getAttribute("PostalAddressPostalCode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("postalAddressPostalCode", "");
                        }
                        try {
                            jsonObjectR3.put("postalAddressLines", row.getAttribute("PostalAddressLines").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("postalAddressLines", "");
                        }
                        try {
                            jsonObjectR3.put("postalAddressCityName",
                                             row.getAttribute("PostalAddressCityName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("postalAddressCityName", "");
                        }
                        try {
                            jsonObjectR3.put("postalAddressStateName",
                                             row.getAttribute("PostalAddressStateName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("postalAddressStateName", "");
                        }
                        try {
                            jsonObjectR3.put("faxAddress", row.getAttribute("FaxAddress").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("faxAddress", "");
                        }
                        try {
                            jsonObjectR3.put("postalAddressCountryName",
                                             row.getAttribute("PostalAddressCountryName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("postalAddressCountryName", "");
                        }
                        try {
                            jsonObjectR3.put("studySiteEid", row.getAttribute("StudySiteEid").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("studySiteEid", "");
                        }
                        try {
                            jsonObjectR3.put("siteName", row.getAttribute("SiteName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("siteName", "");
                        }

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("trialCode", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/siteInformation")
    public String getECGsiteInfoMo(@QueryParam("countryCodeVal") String countryCode,
                                   @QueryParam("studycodeAliasVal") String studyCodeAlias,
                                   @QueryParam("personalIdVal") String personalId,
                                   @QueryParam("siteIdVal") String siteId, @QueryParam("prefixVal") String prefix) {

        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("SiteInfoEcgMO1");
                vo.setNamedWhereClauseParam("personalId", personalId);
                vo.setNamedWhereClauseParam("countryCode", countryCode);
                vo.setNamedWhereClauseParam("studyCodeAlias", studyCodeAlias);
                vo.setNamedWhereClauseParam("siteId", siteId);

                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put(prefix + "SiteId", row.getAttribute("StudySiteId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SiteId", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "ProtocolId", row.getAttribute("StudyCodeAlias").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "ProtocolId", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "SiteName", row.getAttribute("SiteName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SiteName", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "ZipCode",
                                             row.getAttribute("PostalAddressPostalCode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "ZipCode", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "SiteAddress", row.getAttribute("PostalAddressLines").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SiteAddress", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "Country",
                                             row.getAttribute("PostalAddressCountryName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "Country", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "City", row.getAttribute("PostalAddressCityName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "City", "");
                        }


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("trialCode", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }

    @GET
    @Path("/PIInfo")
    public String getECGPInfo(@QueryParam("countryCodeVal") String countryCode,
                              @QueryParam("trailIDVal") String trailID1,
                              @QueryParam("RoleofInvestigator") String roleOfInvestigator,
                              @QueryParam("siteIdVal") String siteID, @QueryParam("prefixVal") String prefix) {

        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("InfoECG1_1");
                vo.setNamedWhereClauseParam("countryCode", countryCode);
                vo.setNamedWhereClauseParam("trailID1", trailID1);
                vo.setNamedWhereClauseParam("siteID", siteID);
                vo.setNamedWhereClauseParam("roleOfInvestigator", roleOfInvestigator);

                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put(prefix + "PIFax", row.getAttribute("Pifax").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "PIFax", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "PIFirsName", row.getAttribute("Pifirstname").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "PIFirstName", "");

                        }
                        try {
                            jsonObjectR3.put(prefix + "PILastName", row.getAttribute("Pilastname").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "PILastName", "");

                        }

                        try {
                            jsonObjectR3.put(prefix + "PIMailAddress", row.getAttribute("Pimailaddress").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "PIMailAddress", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "PIPhone", row.getAttribute("Piphone").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "PIPhone", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "CoordinatorName",
                                             row.getAttribute("RoleAtSiteLvlCode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "CoordinatorName", "");
                        }


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("trialCode", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }

    @GET
    @Path("/CRAInfo")
    public String getECGCRAInfo(@QueryParam("countryCodeVal") String countryCode,
                                @QueryParam("trailIDVal") String trailID1,
                                @QueryParam("RoleofInvestigator") String roleOfInvestigator,
                                @QueryParam("siteIdVal") String siteID, @QueryParam("prefixVal") String prefix) {

        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("InfoEcgCRA1");
                vo.setNamedWhereClauseParam("countryCode", countryCode);
                vo.setNamedWhereClauseParam("trailID1", trailID1);
                vo.setNamedWhereClauseParam("siteID", siteID);
                vo.setNamedWhereClauseParam("roleOfInvestigator", roleOfInvestigator);

                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put(prefix + "CRAFax", row.getAttribute("Crafax").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "CRAFax", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "CRAName", row.getAttribute("Craname").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "CRAName", "");

                        }

                        try {
                            jsonObjectR3.put(prefix + "CRAEMailID", row.getAttribute("Cramailaddress").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "CRAEMailID", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "CRAPhone", row.getAttribute("Craphone").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "CRAPhone", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "CoordinatorName",
                                             row.getAttribute("RoleAtSiteLvlCode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "CoordinatorName", "");
                        }


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("trialCode", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }

    @GET
    @Path("/SCInfo")
    public String getECGSCInfo(@QueryParam("countryCodeVal") String countryCode,
                               @QueryParam("trailIDVal") String trailID1,
                               @QueryParam("RoleofInvestigator") String roleOfInvestigator,
                               @QueryParam("siteIdVal") String siteID, @QueryParam("prefixVal") String prefix) {

        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("InfoEcgSC1");
                vo.setNamedWhereClauseParam("countryCode", countryCode);
                vo.setNamedWhereClauseParam("trailID1", trailID1);
                vo.setNamedWhereClauseParam("siteID", siteID);
                vo.setNamedWhereClauseParam("roleOfInvestigator", roleOfInvestigator);

                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put(prefix + "SCFax", row.getAttribute("Scfax").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SCFax", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "SCFirsName", row.getAttribute("Scfirstname").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SCFirstName", "");

                        }
                        try {
                            jsonObjectR3.put(prefix + "SCLastName", row.getAttribute("Sclastname").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SCLastName", "");

                        }

                        try {
                            jsonObjectR3.put(prefix + "SCMailAddress", row.getAttribute("Scmailaddress").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SCMailAddress", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "SCPhone", row.getAttribute("Scphone").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SCPhone", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "CoordinatorName",
                                             row.getAttribute("RoleAtSiteLvlCode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "CoordinatorName", "");
                        }


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("trialCode", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }

    @GET
    @Path("/SIINFO")
    public String getECGSInfo(@QueryParam("countryCodeVal") String countryCode,
                              @QueryParam("trailIDVal") String trailID1,
                              @QueryParam("RoleofInvestigator") String roleOfInvestigator,
                              @QueryParam("siteIdVal") String siteID, @QueryParam("prefixVal") String prefix) {

        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("InfoECGSI1");
                vo.setNamedWhereClauseParam("countryCode", countryCode);
                vo.setNamedWhereClauseParam("trailID1", trailID1);
                vo.setNamedWhereClauseParam("siteID", siteID);
                vo.setNamedWhereClauseParam("roleOfInvestigator", roleOfInvestigator);

                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put(prefix + "SIFax", row.getAttribute("Sifax").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SIFax", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "SIFirsName", row.getAttribute("Sifirstname").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SIFirstName", "");

                        }
                        try {
                            jsonObjectR3.put(prefix + "SILastName", row.getAttribute("Silastname").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SILastName", "");

                        }

                        try {
                            jsonObjectR3.put(prefix + "SIMailAddress", row.getAttribute("Simailaddress").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SIMailAddress", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "SIPhone", row.getAttribute("Siphone").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "SIPhone", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "CoordinatorName",
                                             row.getAttribute("RoleAtSiteLvlCode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "CoordinatorName", "");
                        }


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("trialCode", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/IRTFormCenter")
    public String IRTformCenter(@QueryParam("stateCodeVal") String stateCode,
                                @QueryParam("countryCodeVal") String countryCode,
                                @QueryParam("studyRefVal") String studyRef, @QueryParam("prefixVal") String prefix) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        if (prefix == null || prefix == "") {
            prefix = "CL";
        }
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("IRTFormCenter1");
                vo.setNamedWhereClauseParam("stateCode11", stateCode);
                vo.setNamedWhereClauseParam("countryCode11", countryCode);
                vo.setNamedWhereClauseParam("studyRef11", studyRef);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put(prefix + "ShippingPostCode",
                                             row.getAttribute("PostalAddressPostalCode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "ShippingPostCode", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "CenterType", row.getAttribute("CenterTypeDesc").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "CenterType", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "ShippingStreetAdd1",
                                             row.getAttribute("PostalAddressLines").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "ShippingStreetAdd1", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "ShippingCity",
                                             row.getAttribute("PostalAddressCityName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "ShippingCity", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "ShippingState",
                                             row.getAttribute("PostalAddressStateName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "ShippingState", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "ShippingCountry",
                                             row.getAttribute("PostalAddressCountryName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "ShippingCountry", "");
                        }

                        try {
                            jsonObjectR3.put(prefix + "Department", row.getAttribute("StudySiteEid").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "Department", "");
                        }
                        try {
                            jsonObjectR3.put(prefix + "FacilityName", row.getAttribute("CenterName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put(prefix + "FacilityName", "");
                        }

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("center", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


}


