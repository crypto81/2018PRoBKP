package vpomodel.rest;

import java.util.HashMap;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import oracle.jbo.ApplicationModule;
import oracle.jbo.Row;
import oracle.jbo.ViewObject;
import oracle.jbo.client.Configuration;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Path("userManagement")
@Consumes("application/json")
@Produces("application/json")
public class UserManagementRestServices {
    private static final String amDef = "vpomodel.eo.AppModule";
    private static final String config = "AppModuleLocal";

    public UserManagementRestServices() {
        super();
    }


    @GET
    @Path("/userDetails")
    public String getUserManagementDetails(@QueryParam("searchTextVal") String searchText,
                                           @QueryParam("personalIdVal") String personalId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        ApplicationModule am = null;
        try {
            am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("userGetDetails1");
                vo.setNamedWhereClauseParam("searchText1", "%" + searchText + "%");
                vo.setNamedWhereClauseParam("userId", "%" + personalId + "%");
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("personnelUserId", row.getAttribute("PersonnelUserId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("personnelUserId", "");
                        }

                        try {
                            String personnelId = row.getAttribute("PersonnelUserId").toString();
                            if (personnelId.endsWith("@CA") || personnelId.endsWith("@ca") ||
                                personnelId.endsWith("@Ca") || personnelId.endsWith("@cA")) {
                                jsonObjectR3.put("siterPersonnelFlag", "Y");
                            } else {
                                jsonObjectR3.put("siterPersonnelFlag", "N");
                            }

                        } catch (Exception e) {
                            jsonObjectR3.put("siterPersonnelFlag", "");
                        }

                        try {
                            jsonObjectR3.put("name", row.getAttribute("Name").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("name", "");
                        }
                        try {
                            jsonObjectR3.put("emailAddress", row.getAttribute("EmailAddress").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("emailAddress", "");
                        }
                        try {
                            jsonObjectR3.put("roleDesc", row.getAttribute("RoleDesc").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("roleDesc", "");
                        }

                        try {
                            jsonObjectR3.put("moduleName", row.getAttribute("ModuleAccess").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("moduleName", "");
                        }

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        //e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("userDetails", jsonCountryArrayR2);
                } catch (Exception e) {
                    //e.printStackTrace();
                }

                return jsonObjectR.toString();
            } catch (Exception e) {
                e.printStackTrace();
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }

                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        } finally {
            if (am != null)
                Configuration.releaseRootApplicationModule(am, true);
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/accesHistoryByMe")
    public String getAccessHistoryDetailsByMe(@QueryParam("personnelIdVal") String personnelId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        ApplicationModule am = null;
        try {
            am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("AccessHistoryByMe1220_1");
                vo.setNamedWhereClauseParam("accessByMeU1", personnelId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("userId", row.getAttribute("UserId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("userId", "");
                        }
                        try {
                            jsonObjectR3.put("name", row.getAttribute("Name").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("name", "");
                        }
                        try {
                            jsonObjectR3.put("emailAddress", row.getAttribute("Email").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("emailAddress", "");
                        }
                        try {
                            jsonObjectR3.put("personalUserid", "");
                        } catch (Exception e) {
                            jsonObjectR3.put("personalUserid", "");
                        }
                        try {
                            jsonObjectR3.put("roleDesc", row.getAttribute("RoleDesc").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("roleDesc", "");
                        }

                        try {
                            jsonObjectR3.put("fromDate", row.getAttribute("FromDate").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("fromDate", "");
                        }
                        try {
                            jsonObjectR3.put("toDate", row.getAttribute("ToDate").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("toDate", "");
                        }

                        try {
                            jsonObjectR3.put("fromUserId", row.getAttribute("FromUserId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("fromUserId", "");
                        }

                        try {
                            jsonObjectR3.put("delegationId", row.getAttribute("DelegationId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("delegationId", "");
                        }
                        try {
                            jsonObjectR3.put("urDelegationFlag", row.getAttribute("UrDelegationFlag").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("urDelegationFlag", "");
                        }
                        try {
                            jsonObjectR3.put("toUserId", row.getAttribute("ToUserId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("toUserId", "");
                        }

                        try {
                            if (personnelId.endsWith("@CA") || personnelId.endsWith("@ca") ||
                                personnelId.endsWith("@Ca") || personnelId.endsWith("@cA")) {
                                jsonObjectR3.put("siterPersonnelFlag", "Y");
                            } else {
                                jsonObjectR3.put("siterPersonnelFlag", "N");
                            }

                        } catch (Exception e) {
                            jsonObjectR3.put("siterPersonnelFlag", "");
                        }

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        //e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("accessHistoryByMe", jsonCountryArrayR2);
                } catch (Exception e) {
                    //e.printStackTrace();
                }

                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }

                return jsonObjectR.toString();

            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        } finally {
            if (am != null)
                Configuration.releaseRootApplicationModule(am, true);
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/accesHistoryToMe")
    public String getAccessHistoryDetailsToMe(@QueryParam("personnelIdVal") String personnelId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        ApplicationModule am = null;
        try {
            am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("AccessToMeCH1_1");
                vo.setNamedWhereClauseParam("toMePersonelId", personnelId);
                vo.executeQuery();
                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("userId", row.getAttribute("Userid").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("userId", "");
                        }
                        try {
                            jsonObjectR3.put("name", row.getAttribute("Name").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("name", "");
                        }
                        try {
                            jsonObjectR3.put("emailAddress", row.getAttribute("Email").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("emailAddress", "");
                        }
                        try {
                            jsonObjectR3.put("personalUserid", "");
                        } catch (Exception e) {
                            jsonObjectR3.put("personalUserid", "");
                        }
                        try {
                            jsonObjectR3.put("roleDesc", row.getAttribute("Roledesc").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("roleDesc", "");
                        }
                        try {
                            jsonObjectR3.put("fromdate", row.getAttribute("FromDate").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("fromdate", "");
                        }
                        try {
                            jsonObjectR3.put("todate", row.getAttribute("ToDate").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("todate", "");
                        }
                        try {
                            jsonObjectR3.put("fromUserId", row.getAttribute("FromUserId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("fromUserId", "");
                        }
                        try {
                            jsonObjectR3.put("toUserId", row.getAttribute("ToUserId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("toUserId", "");
                        }
                        try {
                            jsonObjectR3.put("delegationId", row.getAttribute("DelegationId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("delegationId", "");
                        }
                        try {
                            jsonObjectR3.put("urDelegationFlag", row.getAttribute("UrDelegationFlag").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("urDelegationFlag", "");
                        }

                        try {
                            if (personnelId.endsWith("@CA") || personnelId.endsWith("@ca") ||
                                personnelId.endsWith("@Ca") || personnelId.endsWith("@cA")) {
                                jsonObjectR3.put("siterPersonnelFlag", "Y");
                            } else {
                                jsonObjectR3.put("siterPersonnelFlag", "N");
                            }

                        } catch (Exception e) {
                            jsonObjectR3.put("siterPersonnelFlag", "");
                        }

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        //e.printStackTrace();
                        e.getMessage();
                    }
                }
                try {
                    jsonObjectR.put("accessHistoryToMe", jsonCountryArrayR2);
                } catch (Exception e) {
                    //e.printStackTrace();
                    e.getMessage();
                }

                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }

                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        } finally {
            if (am != null)
                Configuration.releaseRootApplicationModule(am, true);
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/delegateAccessUsers")
    public String requestDelegateAccess(@QueryParam("personnelIdVal") String personnelId) {

        JSONArray allSites = new JSONArray();
        JSONObject allSitesObj = new JSONObject();
        ApplicationModule am = null;
        try {
            allSitesObj.put("value", "/All Sites");
            allSitesObj.put("label", "All Sites");
            am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("DelegateAccess1_1");
                vo.setNamedWhereClauseParam("pId1", personnelId);
                vo.executeQuery();
                JSONArray trials = new JSONArray();
                HashMap<String, Object> trialsHashMap = new HashMap<String, Object>();
                int i = 0;

                while (vo.hasNext()) {
                    boolean add = false;
                    try {
                        Row row = vo.next();
                        ViewObject vo1 = am.findViewObject("DelegateAccess2_1");
                        vo1.setNamedWhereClauseParam("pId2", personnelId);
                        vo1.setNamedWhereClauseParam("codeAlias2", row.getAttribute("StudyCodeAlias").toString());
                        vo1.executeQuery();


                        JSONArray country = new JSONArray();
                        HashMap<String, Object> countryHashMap = new HashMap<String, Object>();
                        int k = 0;

                        while (vo1.hasNext()) {
                            try {
                                Row row1 = vo1.next();


                                ViewObject vo2 = am.findViewObject("DelegateAccess3_1");
                                vo2.setNamedWhereClauseParam("codeAlias3",
                                                             row.getAttribute("StudyCodeAlias").toString());
                                vo2.setNamedWhereClauseParam("countryCode3",
                                                             row1.getAttribute("CountryCode").toString());
                                vo2.setNamedWhereClauseParam("pId3", personnelId);
                                vo2.executeQuery();

                                JSONArray siteInformation = new JSONArray();

                                int count = 0;
                                while (vo2.hasNext()) {

                                    HashMap<String, String> siteValues = new HashMap<String, String>();
                                    try {
                                        Row row2 = vo2.next();
                                        siteValues.put("value",
                                                       "/All Sites/" + row.getAttribute("StudyCodeAlias").toString() +
                                                       "/" + row1.getAttribute("CountryCode").toString() + "/" +
                                                       row2.getAttribute("StudySiteId").toString());
                                        siteValues.put("label", row2.getAttribute("StudySiteId").toString());

                                        JSONObject sitesInfoObj = new JSONObject(siteValues);
                                        siteInformation.put(count, sitesInfoObj);
                                        count++;
                                        add = true;
                                    } catch (Exception e) {
                                        e.getMessage();
                                    }
                                }

                                if (add) {
                                    countryHashMap.put("value",
                                                       "/All Sites/" + row.getAttribute("StudyCodeAlias").toString() +
                                                       "/" + row1.getAttribute("CountryCode").toString());
                                    countryHashMap.put("label", row1.getAttribute("CountryCode").toString());

                                    countryHashMap.put("children", siteInformation);
                                }

                            } catch (Exception e) {
                                //e.printStackTrace();
                                e.getMessage();
                            }

                            if (add) {
                                JSONObject countryObj = new JSONObject(countryHashMap);
                                country.put(k, countryObj);
                                k++;

                            }
                        }
                        if (add) {
                            trialsHashMap.put("value", "/All Sites/" + row.getAttribute("StudyCodeAlias").toString());
                            trialsHashMap.put("label", row.getAttribute("StudyCodeAlias").toString());
                            trialsHashMap.put("children", country);
                        }

                    } catch (Exception e) {
                        //e.printStackTrace();
                        e.getMessage();
                    }
                    if (add) {
                        JSONObject trialsObj = new JSONObject(trialsHashMap);
                        trials.put(i, trialsObj);
                        i++;
                    }
                }

                allSitesObj.put("children", trials);

            } catch (Exception e) {
                allSitesObj.put("children", "ERRORED");
            }

            allSites.put(0, allSitesObj);
            return allSites.toString();
        } catch (Exception e) {
            return "FAILED";
        } finally {
            if (am != null)
                Configuration.releaseRootApplicationModule(am, true);
        }

    }


    @GET
    @Path("/delegateSelectForms")
    public String requestDelegateAccessSelectForms(@QueryParam("personnelIdVal") String personnelId,
                                                   @QueryParam("statusVal") String status) {

        JSONArray allSites = new JSONArray();
        JSONObject allSitesObj = new JSONObject();
        ApplicationModule am = null;
        try {
            allSitesObj.put("value", "/All Sites");
            allSitesObj.put("label", "All Sites");
            am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("DelegateAccess21_1");
                vo.setNamedWhereClauseParam("personnelId", personnelId);
                vo.setNamedWhereClauseParam("status", status);
                vo.executeQuery();
                JSONArray trials = new JSONArray();
                HashMap<String, Object> trailsHashMap = new HashMap<String, Object>();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        trailsHashMap.put("value", "/All Sites/" + row.getAttribute("StudyCodeAlias").toString());
                        trailsHashMap.put("label", row.getAttribute("StudyCodeAlias").toString());
                        ViewObject vo1 = am.findViewObject("DelegateAccess22_1");
                        vo1.setNamedWhereClauseParam("personnelId", personnelId);
                        vo1.setNamedWhereClauseParam("status", status);
                        vo1.setNamedWhereClauseParam("codeAlias", row.getAttribute("StudyCodeAlias").toString());
                        vo1.executeQuery();
                        JSONArray country = new JSONArray();
                        HashMap<String, Object> countryHashMap = new HashMap<String, Object>();

                        int k = 0;
                        while (vo1.hasNext()) {

                            try {
                                Row row1 = vo1.next();

                                countryHashMap.put("value",
                                                   "/All Sites/" + row.getAttribute("StudyCodeAlias").toString() + "/" +
                                                   row1.getAttribute("CountryCode").toString());
                                countryHashMap.put("label", row1.getAttribute("CountryCode").toString());
                                ViewObject vo2 = am.findViewObject("DelegateAccess23_1");
                                vo2.setNamedWhereClauseParam("codeAlias",
                                                             row.getAttribute("StudyCodeAlias").toString());
                                vo2.setNamedWhereClauseParam("countryCode",
                                                             row1.getAttribute("CountryCode").toString());
                                vo2.setNamedWhereClauseParam("personnelId", personnelId);
                                vo2.setNamedWhereClauseParam("status", status);
                                vo2.executeQuery();
                                JSONArray siteInformation = new JSONArray();

                                int count = 0;
                                while (vo2.hasNext()) {
                                    HashMap<String, String> siteValues = new HashMap<String, String>();
                                    try {
                                        Row row2 = vo2.next();
                                        siteValues.put("value",
                                                       "/All Sites/" + row.getAttribute("StudyCodeAlias").toString() +
                                                       "/" + row1.getAttribute("CountryCode").toString() + "/" +
                                                       row2.getAttribute("StudySiteId").toString());
                                        siteValues.put("label", row2.getAttribute("StudySiteId").toString());
                                        JSONObject sitesInfoObj = new JSONObject(siteValues);
                                        siteInformation.put(count, sitesInfoObj);
                                        count++;
                                    } catch (Exception e) {
                                        e.getMessage();
                                    }
                                }

                                countryHashMap.put("children", siteInformation);
                            } catch (Exception e) {
                                //e.printStackTrace();
                                e.getMessage();
                            }
                            JSONObject countryObj = new JSONObject();
                            country.put(k, countryObj);
                            k++;
                        }
                        trailsHashMap.put("children", country);
                    } catch (Exception e) {
                        //e.printStackTrace();
                        e.getMessage();
                    }
                    JSONObject trialsObj = new JSONObject();
                    trials.put(i, trialsObj);
                    i++;
                }
                allSitesObj.put("children", trials);
            } catch (Exception e) {
                allSitesObj.put("children", "ERRORED");
            }

            allSites.put(0, allSitesObj);
            return allSites.toString();
        } catch (Exception e) {
            return "FAILED";
        } finally {
            if (am != null)
                Configuration.releaseRootApplicationModule(am, true);
        }

    }

    //    @GET
    //    @Path("/completeDetails")
    //    public String completePersonnelDetails(@QueryParam("personnelIdVal") String personnelId) {
    //        JSONObject jsonObjectR = new JSONObject();
    //        JSONArray jsonCountryArrayR2 = new JSONArray();
    //        try {
    //            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
    //            try {
    //                ViewObject vo = am.findViewObject("CompletePersonnelDetails1");
    //                vo.setNamedWhereClauseParam("usrMgnt_personnelId", personnelId);
    //                vo.executeQuery();
    //
    //                int i = 0;
    //                while (vo.hasNext()) {
    //                    try {
    //                        Row row = vo.next();
    //                        JSONObject jsonObjectR3 = new JSONObject();
    //                        try {
    //                            jsonObjectR3.put("personnelUserId", row.getAttribute("PersonnelUserId").toString());
    //                        } catch (Exception e) {
    //                            jsonObjectR3.put("personnelUserId", "");
    //                        }
    //                        try {
    //                            jsonObjectR3.put("name", row.getAttribute("Name").toString());
    //                        } catch (Exception e) {
    //                            jsonObjectR3.put("name", "");
    //                        }
    //                        try {
    //                            jsonObjectR3.put("emailAddress", row.getAttribute("EmailAddress").toString());
    //                        } catch (Exception e) {
    //                            jsonObjectR3.put("emailAddress", "");
    //                        }
    //                        try {
    //                            jsonObjectR3.put("roleDesc", row.getAttribute("RoleDesc").toString());
    //                        } catch (Exception e) {
    //                            jsonObjectR3.put("roleDesc", "");
    //                        }
    //                        try {
    //                            jsonObjectR3.put("moduleName", row.getAttribute("ModuleName").toString());
    //                        } catch (Exception e) {
    //                            jsonObjectR3.put("moduleName", "");
    //                        }
    //
    //
    //                        jsonCountryArrayR2.put(i, jsonObjectR3);
    //                        i++;
    //                    } catch (Exception e) {
    //                        //e.printStackTrace();
    //                    }
    //                }
    //                try {
    //                    jsonObjectR.put("completeDetails", jsonCountryArrayR2);
    //                } catch (Exception e) {
    //                    //e.printStackTrace();
    //                }
    //                Configuration.releaseRootApplicationModule(am, true);
    //                return jsonObjectR.toString();
    //            } catch (Exception e) {
    //                try {
    //                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
    //                } catch (JSONException f) {
    //                    f.printStackTrace();
    //                }
    //                Configuration.releaseRootApplicationModule(am, true);
    //                return jsonObjectR.toString();
    //            }
    //        } catch (Exception e) {
    //            jsonObjectR = new JSONObject();
    //            try {
    //                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
    //            } catch (JSONException f) {
    //                f.printStackTrace();
    //            }
    //        }
    //        return jsonObjectR.toString();
    //    }


    @GET
    @Path("/showFormNames")
    public String showFormNames(@QueryParam("personnelIdVal") String personnelId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        ApplicationModule am = null;
        try {
            am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("ShowFormNames1");
                vo.setNamedWhereClauseParam("userMgt_personnelId", personnelId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("formId", row.getAttribute("FormId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formId", "");
                        }
                        try {
                            jsonObjectR3.put("formName", row.getAttribute("FormName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("formName", "");
                        }
                        try {
                            jsonObjectR3.put("vendorCategoryName", row.getAttribute("VendorCategoryName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorCategoryName", "");
                        }
                        try {
                            jsonObjectR3.put("vendorName", row.getAttribute("VendorName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorName", "");
                        }
                        try {
                            jsonObjectR3.put("submissionDueDate", row.getAttribute("SubmissionDueDate").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("submissionDueDate", "");
                        }
                        try {
                            jsonObjectR3.put("createdBy", row.getAttribute("CreatedBy").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("createdBy", "");
                        }

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        //e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("formNames", jsonCountryArrayR2);
                } catch (Exception e) {
                    //e.printStackTrace();
                }
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        } finally {
            if (am != null)
                Configuration.releaseRootApplicationModule(am, true);
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/delegateIdentify")
    public String getDelegateIdentify(@QueryParam("vendorFormIdVal") String vendorFormId) {
        JSONObject jsonObjectR = new JSONObject();
        ApplicationModule am = null;
        try {
            am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("DelegateIdentify1");
                vo.setNamedWhereClauseParam("vendorFormId", vendorFormId);
                vo.executeQuery();

                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();

                        try {
                            jsonObjectR.put("j1", row.getAttribute("J1").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("j1", "");
                        }
                    } catch (Exception e) {
                        //e.printStackTrace();
                        e.getMessage();
                    }
                }


                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }

                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        } finally {
            if (am != null)
                Configuration.releaseRootApplicationModule(am, true);
        }
        return jsonObjectR.toString();
    }

    @GET
    @Path("/sitePersonDtls")
    public String GetSitePersnlId(@QueryParam("countryCodeVal") String countryCode,
                                  @QueryParam("studyCodeAliasVal") String studyCodeAlias,
                                  @QueryParam("studySiteIdVal") String studySiteId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        ApplicationModule am = null;
        try {
            am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("GetSitePersnlId1");
                vo.setNamedWhereClauseParam("studySiteId1", studySiteId);
                vo.setNamedWhereClauseParam("countryCode", countryCode);
                vo.setNamedWhereClauseParam("studyCodeAlias", studyCodeAlias);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("studySitePersonnelIdVpo",
                                             row.getAttribute("StudySitePersonnelIdVpo").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("studySitePersonnelIdVpo", "");
                        }
                        try {
                            jsonObjectR3.put("personnelId", row.getAttribute("PersonnelId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("personnelId", "");
                        }

                        try {
                            jsonObjectR3.put("personnelId1", row.getAttribute("PersonnelId1").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("personnelId1", "");
                        }

                        try {
                            jsonObjectR3.put("name", row.getAttribute("SitePersonnelName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("name", "");
                        }

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        //e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("sitePersonnelDtls", jsonCountryArrayR2);
                } catch (Exception e) {
                    //e.printStackTrace();
                }

                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }

                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        } finally {
            if (am != null)
                Configuration.releaseRootApplicationModule(am, true);
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/showFrstnLastNm")
    public String ShowFrstnLastNm(@QueryParam("studysiteIdVal") String studySiteId,
                                  @QueryParam("studyCodeAliasVal") String studyCodeAlias,
                                  @QueryParam("countryCodeVal") String countryCode) {
        JSONObject jsonObjectR = new JSONObject();
        ApplicationModule am = null;
        try {
            am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("ShowFrstnLastNme1");
                vo.setNamedWhereClauseParam("studySiteId", studySiteId);
                vo.setNamedWhereClauseParam("studyCodeAlias", studyCodeAlias);
                vo.setNamedWhereClauseParam("countryCode", countryCode);
                vo.executeQuery();

                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();

                        try {
                            jsonObjectR.put("personnelId", row.getAttribute("PersonnelId").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("personnelId", "");

                        }
                        try {
                            jsonObjectR.put("noName", row.getAttribute("NoName").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("noName", "");

                        }

                    } catch (Exception e) {
                        //e.printStackTrace();
                        e.getMessage();
                    }
                }

                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        } finally {
            if (am != null)
                Configuration.releaseRootApplicationModule(am, true);
        }
        return jsonObjectR.toString();
    }

    @GET
    @Path("/FirstnLast")
    public String FrstnLast(@QueryParam("studySiteIdVal") String studysiteId,
                            @QueryParam("studyCodeVal") String studyCodeAlias,
                            @QueryParam("countryCodeVal") String countryCode) {
        JSONObject jsonObjectR = new JSONObject();
        ApplicationModule am = null;
        try {
            am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("FrstnLast1");
                vo.setNamedWhereClauseParam("studysiteId", studysiteId);
                vo.setNamedWhereClauseParam("studyCodeAlias", studyCodeAlias);
                vo.setNamedWhereClauseParam("countryCode", countryCode);
                vo.executeQuery();

                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();

                        try {
                            jsonObjectR.put("personnelId", row.getAttribute("PersonnelId").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("personnelId", "");

                        }
                        try {
                            jsonObjectR.put("sitePersonnelName", row.getAttribute("SitePersonnelName").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("sitePersonnelName", "");

                        }

                    } catch (Exception e) {
                        //e.printStackTrace();
                        e.getMessage();
                    }
                }


                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }

                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        } finally {
            if (am != null)
                Configuration.releaseRootApplicationModule(am, true);
        }
        return jsonObjectR.toString();
    }

    @GET
    @Path("/revokeDelegation")
    public String getRevokeDelegation(@QueryParam("personnelUserIdVal") String personnelUserId) {
        JSONObject jsonObjectR = new JSONObject();
        ApplicationModule am = null;
        try {
            am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("RevokeDeligation1");
                vo.setNamedWhereClauseParam("personnelUserId", personnelUserId);

                vo.executeQuery();

                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();

                        try {
                            jsonObjectR.put("delegationId", row.getAttribute("DelegationId").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("delegationId", "");

                        }
                        try {
                            jsonObjectR.put("formDelegationId", row.getAttribute("FormDelegationId").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("formDelegationId", "");

                        }

                        try {
                            jsonObjectR.put("vendorFormId", row.getAttribute("VendorFormId").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("vendorFormId", "");

                        }
                        try {
                            jsonObjectR.put("delgationId", row.getAttribute("DelgationId").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("delgationId", "");

                        }
                        try {
                            jsonObjectR.put("formDelFlag", row.getAttribute("FormDelFlag").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("formDelFlag", "");

                        }
                        try {
                            jsonObjectR.put("fromUserId", row.getAttribute("FromUserId").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("fromUserId", "");

                        }
                        try {
                            jsonObjectR.put("toUserId", row.getAttribute("ToUserId").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("toUserId", "");

                        }
                        try {
                            jsonObjectR.put("roleId", row.getAttribute("RoleId").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("roleId", "");

                        }

                        try {
                            jsonObjectR.put("startDate", row.getAttribute("StartDate").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("startDate", "");

                        }
                        try {
                            jsonObjectR.put("endDate", row.getAttribute("EndDate").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("endDate", "");

                        }
                        try {
                            jsonObjectR.put("urDelegationFlag", row.getAttribute("UrDelegationFlag").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("urDelegationFlag", "");

                        }


                    } catch (Exception e) {
                        //e.printStackTrace();
                        e.getMessage();
                    }
                }


                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }

                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        } finally {
            if (am != null)
                Configuration.releaseRootApplicationModule(am, true);
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/revokeAccessUsers")
    public String requestRevokeAccess(@QueryParam("userIdVal") String userId,
                                      @QueryParam("fromDateVal") String fromDate,
                                      @QueryParam("endDateVal") String endDate,
                                      @QueryParam("dFlagVal") String delegationFlag) {

        JSONArray allSites = new JSONArray();
        JSONObject allSitesObj = new JSONObject();
        ApplicationModule am = null;
        try {
            allSitesObj.put("value", "/All Sites");
            allSitesObj.put("label", "All Sites");
            am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("DelegateRevokeAccessStudy1");
                vo.setNamedWhereClauseParam("personnelIdRevoke", userId);
                vo.executeQuery();
                JSONArray trials = new JSONArray();
                HashMap<String, Object> trialsHashMap = new HashMap<String, Object>();
                int i = 0;
                while (vo.hasNext()) {
                    boolean add = false;
                    try {
                        Row row = vo.next();

                        ViewObject vo1 = am.findViewObject("DelegateRevokeAccessCountry1");
                        vo1.setNamedWhereClauseParam("personnelCountry", userId);
                        vo1.setNamedWhereClauseParam("studyCodeCountry", row.getAttribute("StudyCodeAlias").toString());
                         vo1.setNamedWhereClauseParam("delegationFlagCountry", delegationFlag);
                        vo1.executeQuery();
                        JSONArray country = new JSONArray();

                        HashMap<String, Object> countryHashMap = new HashMap<String, Object>();
                        int k = 0;
                        while (vo1.hasNext()) {

                            try {
                                Row row1 = vo1.next();
                                ViewObject vo2 = am.findViewObject("DelegateRevokeAccessSiteMO1");
                                vo2.setNamedWhereClauseParam("countryCodeRA",
                                                             row1.getAttribute("CountryCode").toString());
                                vo2.setNamedWhereClauseParam("delegationFlagRA", delegationFlag);
                                vo2.setNamedWhereClauseParam("endDateRA", endDate);
                                vo2.setNamedWhereClauseParam("fromDateRA", fromDate);
                                vo2.setNamedWhereClauseParam("personnelSite", userId);
                                vo2.setNamedWhereClauseParam("studyCodeAliasRA",
                                                             row.getAttribute("StudyCodeAlias").toString());

                                vo2.executeQuery();
                                JSONArray siteInformation = new JSONArray();

                                int count = 0;
                                while (vo2.hasNext()) {
                                    HashMap<String, String> siteValues = new HashMap<String, String>();
                                    try {
                                        Row row2 = vo2.next();
                                        siteValues.put("value",
                                                       "/All Sites/" + row.getAttribute("StudyCodeAlias").toString() +
                                                       "/" + row1.getAttribute("CountryCode").toString() + "/" +
                                                       row2.getAttribute("StudySiteId").toString());
                                        siteValues.put("label", row2.getAttribute("StudySiteId").toString());

                                        JSONObject sitesInfoObj = new JSONObject(siteValues);
                                        siteInformation.put(count, sitesInfoObj);
                                        count++;
                                        add = true;
                                    } catch (Exception e) {
                                        e.getMessage();
                                    }
                                }
                                if (add) {
                                    countryHashMap.put("value",
                                                       "/All Sites/" + row.getAttribute("StudyCodeAlias").toString() +
                                                       "/" + row1.getAttribute("CountryCode").toString());
                                    countryHashMap.put("label", row1.getAttribute("CountryCode").toString());
                                    countryHashMap.put("children", siteInformation);
                                }
                            } catch (Exception e) {
                                //e.printStackTrace();
                                e.getMessage();
                            }
                            if (add) {
                                JSONObject countryObj = new JSONObject(countryHashMap);
                                country.put(k, countryObj);
                                k++;
                            }
                        }
                        if (add) {
                            trialsHashMap.put("value", "/All Sites/" + row.getAttribute("StudyCodeAlias").toString());
                            trialsHashMap.put("label", row.getAttribute("StudyCodeAlias").toString());
                            trialsHashMap.put("children", country);

                        }
                    } catch (Exception e) {
                        //e.printStackTrace();
                        e.getMessage();
                    }
                    if (add) {
                        JSONObject trialsObj = new JSONObject(trialsHashMap);
                        trials.put(i, trialsObj);
                        i++;
                    }
                }
                allSitesObj.put("children", trials);

            } catch (Exception e) {
                allSitesObj.put("children", "ERRORED");
            }

            allSites.put(0, allSitesObj);
            return allSites.toString();
        } catch (Exception e) {
            return "FAILED";
        } finally {
            if (am != null)
                Configuration.releaseRootApplicationModule(am, true);
        }
    }


    @GET
    @Path("/userData")
    public String getUserInfo(@QueryParam("urStatus") String userStatus, @QueryParam("rgStatus") String regionStatus,
                              @QueryParam("personnelId") String personnelId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        ApplicationModule am = null;
        try {
            am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("UserInfo1");
                vo.setNamedWhereClauseParam("roleStatus", regionStatus);
                vo.setNamedWhereClauseParam("userStatus", userStatus);
                vo.setNamedWhereClauseParam("personnelId", personnelId);
                vo.executeQuery();

                int j = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        String userId;
                        String roleId;
                        String userName;
                        String roleCode;
                        String roleDesc;
                        String moduleName;
                        String startDate;
                        String endDate;
                        String accessType;
                        String personnelUserId;
                        try {
                            userId = row.getAttribute("UserId").toString();
                        } catch (Exception e) {
                            userId = "";
                        }
                        try {
                            roleId = row.getAttribute("RoleId").toString();
                        } catch (Exception e) {
                            roleId = "";
                        }
                        try {
                            userName = row.getAttribute("UserName").toString();
                        } catch (Exception e) {
                            userName = "";
                        }
                        try {
                            roleCode = row.getAttribute("RoleCode").toString();
                        } catch (Exception e) {
                            roleCode = "";
                        }
                        try {
                            roleDesc = row.getAttribute("RoleDesc").toString();
                        } catch (Exception e) {
                            roleDesc = "";
                        }
                        try {
                            moduleName = row.getAttribute("ModuleName").toString();
                        } catch (Exception e) {
                            moduleName = "";
                        }
                        try {
                            accessType = row.getAttribute("AccessType").toString();
                        } catch (Exception e) {
                            accessType = "";
                        }

                        try {
                            startDate = row.getAttribute("StartDate").toString();
                        } catch (Exception e) {
                            startDate = "";
                        }
                        try {
                            endDate = row.getAttribute("EndDate").toString();
                        } catch (Exception e) {
                            endDate = "";
                        }

                        try {
                            personnelUserId = row.getAttribute("PersonnelUserId").toString();
                        } catch (Exception e) {
                            personnelUserId = "";
                        }


                        JSONObject jsonObjectR2 = new JSONObject();
                        jsonObjectR2.put("userId", userId);
                        jsonObjectR2.put("roleId", roleId);
                        jsonObjectR2.put("actualUserName", userName);
                        jsonObjectR2.put("roleCode", roleCode);
                        jsonObjectR2.put("roleDesc", roleDesc);
                        jsonObjectR2.put("moduleName", moduleName);
                        jsonObjectR2.put("accessType", accessType);
                        jsonObjectR2.put("startDate", startDate);
                        jsonObjectR2.put("endDate", endDate);
                        jsonObjectR2.put("userName", personnelUserId);
                        jsonCountryArrayR2.put(j, jsonObjectR2);
                        j++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("userInfo", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    e.printStackTrace();
                    jsonObjectR.put("ERRORMSG", "Server is Down. Please contact administrator.");
                } catch (Exception f) {
                    f.printStackTrace();
                }
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }

        } finally {
            if (am != null)
                Configuration.releaseRootApplicationModule(am, true);
        }
        return jsonObjectR.toString();
    }

}

