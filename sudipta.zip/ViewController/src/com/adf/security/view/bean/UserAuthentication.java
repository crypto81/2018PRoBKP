package com.adf.security.view.bean;

import java.nio.charset.Charset;

import javax.faces.event.ActionEvent;

import oracle.adf.view.rich.component.rich.RichPopup;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import javax.security.auth.Subject;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.FailedLoginException;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import weblogic.security.SimpleCallbackHandler;
import weblogic.security.services.Authentication;

import weblogic.servlet.security.ServletAuthentication;

public class UserAuthentication {
    private String userLoginID;
    private String userPassword;

    public void setUserLoginID(String userLoginID) {
        this.userLoginID = userLoginID;
    }

    public String getUserLoginID() {
        return userLoginID;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public UserAuthentication() {
    }

    public void onLogin(ActionEvent actionEvent) {
        FacesContext ctx = FacesContext.getCurrentInstance();
        if (this.userLoginID == null || this.userLoginID.trim().length() == 0 || this.getUserPassword() == null ||
            this.userPassword.trim().length() == 0) {


        } else {
            try {

                HttpServletRequest req = (HttpServletRequest) ctx.getExternalContext().getRequest();
                System.out.println("Trying to login " + this.userLoginID + " with Charset.defaultCharset() = " +
                                   Charset.defaultCharset());
                byte[] pwd = this.userPassword.getBytes(Charset.defaultCharset());
                CallbackHandler callbackHandler =
                    new SimpleCallbackHandler(this.userLoginID, pwd, Charset.defaultCharset().name());
                Subject sub = Authentication.login(callbackHandler);
                ServletAuthentication.runAs(sub, req);
                ServletAuthentication.generateNewSessionID(req);
                HttpServletResponse res = (HttpServletResponse) ctx.getExternalContext().getResponse();
                RequestDispatcher reqDispatcher =
                    req.getRequestDispatcher("/adfAuthentication?success_url=/faces/Home.jsf");
                reqDispatcher.forward(req, res);
                ctx.responseComplete();

            } catch (Exception e) {
                System.out.println("Error while logging in for User : " + this.userLoginID + e.getMessage());

            }
        }
    }
}
