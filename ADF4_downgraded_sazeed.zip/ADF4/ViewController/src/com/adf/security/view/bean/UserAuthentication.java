package com.adf.security.view.bean;

import java.io.IOException;

import java.nio.charset.Charset;

import javax.faces.application.FacesMessage;
import javax.faces.event.ActionEvent;

import oracle.adf.view.rich.component.rich.RichPopup;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import javax.security.auth.Subject;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.FailedLoginException;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import javax.servlet.http.HttpSession;

import oracle.adf.view.rich.component.rich.layout.RichPanelGroupLayout;
import oracle.adf.view.rich.component.rich.output.RichOutputText;

import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.adf.view.rich.render.ClientEvent;

import oracle.jbo.ApplicationModule;

import oracle.jbo.Row;
import oracle.jbo.ViewObject;
import oracle.jbo.client.Configuration;

import org.apache.myfaces.trinidad.event.AttributeChangeEvent;

import weblogic.security.SimpleCallbackHandler;
import weblogic.security.services.Authentication;

import weblogic.servlet.security.ServletAuthentication;

public class UserAuthentication {
    private String userLoginID = "";
    private String userPassword = "";
    private String errorMessage = "";
    private RichPanelGroupLayout pgBd1;
    private RichOutputText otBd;
    private static final String amDef = "com.adf.security.model.AppModule";
    private static final String config = "AppModuleLocal";

    public void setUserLoginID(String userLoginID) {
        this.userLoginID = userLoginID;
    }

    public String getUserLoginID() {
        return userLoginID;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public UserAuthentication() {
    }

    public String onLogout() {
        String response = "Logout Failed";

        try {
            FacesContext ctx = FacesContext.getCurrentInstance();
            ExternalContext ectx = ctx.getExternalContext();
            HttpServletRequest req = (HttpServletRequest) ctx.getExternalContext().getRequest();
            HttpServletResponse res = (HttpServletResponse) ctx.getExternalContext().getResponse();
            eraseCookie(req, res);
            Cookie cookie = new Cookie("userName", "");
            cookie.setMaxAge(0);
            res.addCookie(cookie);
            Cookie cookie1 = new Cookie("JSESSIONID", "");
            cookie1.setMaxAge(0);
            res.addCookie(cookie1);
            HttpSession session = req.getSession(false);
            session.invalidate();
            String url = ectx.getRequestContextPath() + "/adfAuthentication?logout=true&end_url=/faces/Login.jsf";

            ectx.redirect(url);
            response = "Logout Success";
            ctx.responseComplete();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return response;
    }

    private void eraseCookie(HttpServletRequest req, HttpServletResponse resp) {
        Cookie[] cookies = req.getCookies();
        if (cookies != null)
            for (Cookie cookie : cookies) {
                cookie.setValue("");
                cookie.setPath("/");
                cookie.setMaxAge(0);
                resp.addCookie(cookie);
            }
    }

    public void onLogin(ActionEvent actionEvent) {
        loginMethod();
    }

    public void loginMethod() {

        if (this.userLoginID == null || this.userLoginID
                                            .trim()
                                            .length() == 0 || this.getUserPassword() == null || this.userPassword
                                                                                                    .trim()
                                                                                                    .length() == 0) {


        } else {
            ApplicationModule am = null;
            String access = "NO";
            try {
                am = Configuration.createRootApplicationModule(amDef, config);
                ViewObject vo = am.findViewObject("AccessUsers1");
                vo.setNamedWhereClauseParam("userId", userLoginID);
                vo.executeQuery();
                while (vo.hasNext()) {
                    Row row = vo.next();
                    access = (String) row.getAttribute("UserExist");
                }

                FacesContext ctx = FacesContext.getCurrentInstance();
                if (access.equalsIgnoreCase("YES")) {
                    try {
                        HttpServletRequest req = (HttpServletRequest) ctx.getExternalContext().getRequest();
                        byte[] pwd = this.userPassword.getBytes(Charset.defaultCharset());
                        CallbackHandler callbackHandler =
                            new SimpleCallbackHandler(this.userLoginID, pwd, Charset.defaultCharset().name());
                        Subject sub = Authentication.login(callbackHandler);
                        ServletAuthentication.runAs(sub, req);
                        ServletAuthentication.generateNewSessionID(req);
                        // HttpSession session = req.getSession();
                        // session.setMaxInactiveInterval(30 * 60);
                        HttpServletResponse res = (HttpServletResponse) ctx.getExternalContext().getResponse();
                        Cookie obj = new Cookie("userName", userLoginID);
                        res.addCookie(obj);
                        RequestDispatcher reqDispatcher =
                            req.getRequestDispatcher("/adfAuthentication?success_url=/faces/Dashboard.jsf");
                        reqDispatcher.forward(req, res);
                        ctx.responseComplete();

                    } catch (Exception e) {
                        errorMessage = "Invalid Credentials. Please Try Again.";
                        otBd.setVisible(true);
                        AdfFacesContext.getCurrentInstance().addPartialTarget(otBd);
                        AdfFacesContext.getCurrentInstance().addPartialTarget(pgBd1);
                    }
                } else {
                    errorMessage = "Unauthorized Access. Please Contact System Admin.";
                    otBd.setVisible(true);
                    AdfFacesContext.getCurrentInstance().addPartialTarget(otBd);
                    AdfFacesContext.getCurrentInstance().addPartialTarget(pgBd1);
                }

            } catch (Exception e) {
                errorMessage = "Connection to Server Failed. Please Contact System Administrator.";
                otBd.setVisible(true);
                AdfFacesContext.getCurrentInstance().addPartialTarget(otBd);
                AdfFacesContext.getCurrentInstance().addPartialTarget(pgBd1);
            } finally {
                if (am != null)
                    Configuration.releaseRootApplicationModule(am, true);
            }
        }

    }


    public void onInputLogin(ClientEvent clientEvent) {
        // Add event code here...
        loginMethod();
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setPgBd1(RichPanelGroupLayout pgBd1) {
        this.pgBd1 = pgBd1;
    }

    public RichPanelGroupLayout getPgBd1() {
        return pgBd1;
    }

    public void setOtBd(RichOutputText otBd) {
        this.otBd = otBd;
    }

    public RichOutputText getOtBd() {
        return otBd;
    }

    public void resetMethod(AttributeChangeEvent attributeChangeEvent) {
        // Add event code here...
        errorMessage = "";
        otBd.setVisible(true);
        AdfFacesContext.getCurrentInstance().addPartialTarget(otBd);
        AdfFacesContext.getCurrentInstance().addPartialTarget(pgBd1);
    }
}
