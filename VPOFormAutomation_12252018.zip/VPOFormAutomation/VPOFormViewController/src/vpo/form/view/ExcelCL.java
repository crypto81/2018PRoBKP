package vpo.form.view;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.Properties;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ExcelCL extends HttpServlet {

    private static final long serialVersionUID = 1L;
    Properties prop = new Properties();

    public ExcelCL() {
        super();
    }

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    public void destroy() {
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException,
                                                                                                   IOException {
        OutputStream out = null;
        try {
            InputStream inputStream = getClass().getClassLoader().getResourceAsStream("CL.properties");
            prop.load(inputStream);
            int excelRow = Integer.parseInt(prop.getProperty("ROWNUM").toString());
            String inputJSON = request.getParameter("inputJson");
            JSONObject jsonObj = new JSONObject(inputJSON);
            String trialId = "";
            try {
                if (jsonObj.get("CLTrialCode").toString() != null && !jsonObj.get("CLTrialCode")
                                                                             .toString()
                                                                             .equalsIgnoreCase(null) &&
                    !jsonObj.get("CLTrialCode")
                                                                                                                .toString()
                                                                                                                .equalsIgnoreCase("null")) {
                    trialId = jsonObj.get("CLTrialCode").toString();
                }
            } catch (JSONException e) {
                e.getMessage();
            }
            String siteId = "";
            try {
                if (jsonObj.get("CLSiteId").toString() != null && !jsonObj.get("CLSiteId")
                                                                          .toString()
                                                                          .equalsIgnoreCase(null) &&
                    !jsonObj.get("CLSiteId")
                                                                                                             .toString()
                                                                                                             .equalsIgnoreCase("null")) {
                    siteId = jsonObj.get("CLSiteId").toString();
                }
            } catch (JSONException e) {
                e.getMessage();
            }
            String vendorName = "";
            try {
                if (jsonObj.get("vendorName").toString() != null && !jsonObj.get("vendorName")
                                                                            .toString()
                                                                            .equalsIgnoreCase(null) &&
                    !jsonObj.get("vendorName")
                                                                                                               .toString()
                                                                                                               .equalsIgnoreCase("null")) {
                    vendorName = jsonObj.get("vendorName").toString();
                }
            } catch (JSONException e) {
                e.getMessage();
            }
            SimpleDateFormat formatter = new SimpleDateFormat("ddMMMyy");
            String date = formatter.format(new Date());
            String fileName = "";
            if (trialId != "" && !trialId.equalsIgnoreCase("") && !trialId.equalsIgnoreCase(null) &&
                !trialId.equalsIgnoreCase("null")) {
                fileName = fileName + trialId + "_";
            }
            if (siteId != "" && !siteId.equalsIgnoreCase("") && !siteId.equalsIgnoreCase(null) &&
                !siteId.equalsIgnoreCase("null")) {
                fileName = fileName + siteId + "_";
            }

            if (vendorName != "" && !vendorName.equalsIgnoreCase("") && !vendorName.equalsIgnoreCase(null) &&
                !vendorName.equalsIgnoreCase("null")) {
                fileName = fileName + vendorName + "_";
            }
            fileName = fileName + date + "V1.0.xlsx";
            response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
            InputStream is = this.getClass()
                                 .getClassLoader()
                                 .getResourceAsStream("META-INF/CL.xlsx");
            XSSFWorkbook wb = new XSSFWorkbook(is);
            XSSFSheet sheet = wb.getSheetAt(Integer.parseInt(prop.getProperty("SHEETNUM").toString()));
            XSSFRow row1 = sheet.getRow(6);
            if (row1 == null) {
                row1 = sheet.createRow(6);
            }

            XSSFCell cell = row1.getCell(1);
            if (cell == null) {
                cell = row1.createCell(1);
                cell.setCellType(XSSFCell.CELL_TYPE_STRING);

                cell.setCellValue(vendorName);
            } else {
                cell.setCellValue(vendorName);
            }

            XSSFRow row2 = sheet.getRow(7);
            if (row2 == null) {
                row2 = sheet.createRow(7);
            }

            XSSFCell cell1 = row2.getCell(1);
            if (cell1 == null) {
                cell1 = row2.createCell(1);
                cell1.setCellType(XSSFCell.CELL_TYPE_STRING);
                cell1.setCellValue(trialId);
            } else {
                cell1.setCellValue(trialId);
            }

            XSSFRow row3 = sheet.getRow(8);
            if (row3 == null) {
                row3 = sheet.createRow(8);
            }

            XSSFCell cell3 = row3.getCell(1);
            if (cell3 == null) {
                cell3 = row3.createCell(1);
                cell3.setCellType(XSSFCell.CELL_TYPE_STRING);
                cell3.setCellValue(siteId);
            } else {
                cell3.setCellValue(siteId);
            }

            XSSFRow row5 = sheet.getRow(11);
            if (row5 == null) {
                row5 = sheet.createRow(11);
            }
            try {
                XSSFCell cell4 = row5.getCell(1);
                if (cell4 == null) {
                    cell4 = row5.createCell(1);
                    cell4.setCellType(XSSFCell.CELL_TYPE_STRING);
                    if (jsonObj.get("completedBy").toString() != null && !jsonObj.get("completedBy")
                                                                                 .toString()
                                                                                 .equalsIgnoreCase(null) &&
                        !jsonObj.get("completedBy")
                                                                                                                    .toString()
                                                                                                                    .equalsIgnoreCase("null")) {
                        cell4.setCellValue(jsonObj.get("completedBy").toString());
                    }
                } else {
                    if (jsonObj.get("completedBy").toString() != null && !jsonObj.get("completedBy")
                                                                                 .toString()
                                                                                 .equalsIgnoreCase(null) &&
                        !jsonObj.get("completedBy")
                                                                                                                    .toString()
                                                                                                                    .equalsIgnoreCase("null")) {
                        cell4.setCellValue(jsonObj.get("completedBy").toString());
                    }
                }
            } catch (JSONException e) {
                e.getMessage();

            }
            XSSFRow row4 = sheet.getRow(12);
            if (row4 == null) {
                row4 = sheet.createRow(12);
            }

            XSSFCell cell5 = row4.getCell(1);
            try {
                if (cell5 == null) {
                    cell5 = row4.createCell(1);
                    cell5.setCellType(XSSFCell.CELL_TYPE_STRING);
                    if (jsonObj.get("completedDate").toString() != null && !jsonObj.get("completedDate")
                                                                                   .toString()
                                                                                   .equalsIgnoreCase(null) &&
                        !jsonObj.get("completedDate")
                                                                                                                      .toString()
                                                                                                                      .equalsIgnoreCase("null")) {
                        cell5.setCellValue(jsonObj.get("completedDate").toString());
                    }
                } else {
                    if (jsonObj.get("completedDate").toString() != null && !jsonObj.get("completedDate")
                                                                                   .toString()
                                                                                   .equalsIgnoreCase(null) &&
                        !jsonObj.get("completedDate")
                                                                                                                      .toString()
                                                                                                                      .equalsIgnoreCase("null")) {
                        cell5.setCellValue(jsonObj.get("completedDate").toString());
                    }
                }
            } catch (JSONException e) {
                e.getMessage();

            }
            XSSFRow row = sheet.getRow(excelRow);
            if (row == null) {
                row = sheet.createRow(excelRow);
            }
            for (int i = 1; i <= 35; i++) {

                if (i == 35) {
                    String flag1 = "";
                    String flag2 = "";
                    String flag3 = "";
                    try {
                        if (jsonObj.get(prop.getProperty("350").toString()).toString() != null &&
                            !jsonObj.get(prop.getProperty("350").toString())
                                    .toString()
                                    .equalsIgnoreCase(null) && !jsonObj.get(prop.getProperty("350").toString())
                                                                       .toString()
                                                                       .equalsIgnoreCase("null")) {
                            flag1 = jsonObj.get(prop.getProperty("350").toString()).toString();
                        }

                    } catch (JSONException e) {
                        flag1 = "";
                    }
                    try {
                        if (jsonObj.get(prop.getProperty("351").toString()).toString() != null &&
                            !jsonObj.get(prop.getProperty("351").toString())
                                    .toString()
                                    .equalsIgnoreCase(null) && !jsonObj.get(prop.getProperty("351").toString())
                                                                       .toString()
                                                                       .equalsIgnoreCase("null")) {
                            flag2 = jsonObj.get(prop.getProperty("351").toString()).toString();
                        }
                    } catch (JSONException e) {
                        flag2 = "";
                    }
                    try {
                        if (jsonObj.get(prop.getProperty("352").toString()).toString() != null &&
                            !jsonObj.get(prop.getProperty("352").toString())
                                    .toString()
                                    .equalsIgnoreCase(null) && !jsonObj.get(prop.getProperty("352").toString())
                                                                       .toString()
                                                                       .equalsIgnoreCase("null")) {
                            flag3 = jsonObj.get(prop.getProperty("352").toString()).toString();
                        }
                    } catch (JSONException e) {
                        flag3 = "";

                    }
                    XSSFCell cell7 = row.getCell(i);
                    if (cell7 == null) {
                        cell7 = row.createCell(i);
                        cell7.setCellType(XSSFCell.CELL_TYPE_STRING);
                        cell7.setCellValue(flag1 + flag2 + flag3);
                    } else {
                        cell7.setCellValue(flag1 + flag2 + flag3);
                    }
                } else {
                    try {

                        XSSFCell cell6 = row.getCell(i);
                        if (cell6 == null) {
                            cell6 = row.createCell(i);
                            cell6.setCellType(XSSFCell.CELL_TYPE_STRING);

                            if (jsonObj.get(prop.getProperty(i + "").toString()).toString() != null &&
                                !jsonObj.get(prop.getProperty(i + "").toString())
                                        .toString()
                                        .equalsIgnoreCase(null) && !jsonObj.get(prop.getProperty(i + "").toString())
                                                                           .toString()
                                                                           .equalsIgnoreCase("null")) {
                                cell6.setCellValue(jsonObj.get(prop.getProperty(i + "").toString()).toString());
                            }
                        } else {
                            if (jsonObj.get(prop.getProperty(i + "").toString()).toString() != null &&
                                !jsonObj.get(prop.getProperty(i + "").toString())
                                        .toString()
                                        .equalsIgnoreCase(null) && !jsonObj.get(prop.getProperty(i + "").toString())
                                                                           .toString()
                                                                           .equalsIgnoreCase("null")) {
                                cell6.setCellValue(jsonObj.get(prop.getProperty(i + "").toString()).toString());
                            }
                        }
                    } catch (JSONException e) {
                        e.getMessage();
                    }
                }
            }
            JSONArray jsonObj2 = null;
            try {
                if (jsonObj.getJSONArray(prop.getProperty("ReportShipping").toString()) != null &&
                    !jsonObj.getJSONArray(prop.getProperty("ReportShipping").toString())
                            .toString()
                            .equalsIgnoreCase(null) && !jsonObj.getJSONArray(prop.getProperty("ReportShipping").toString())
                                                               .toString()
                                                               .equalsIgnoreCase("null")) {
                    jsonObj2 = jsonObj.getJSONArray(prop.getProperty("ReportShipping").toString());
                }


                for (int j = 0; j < jsonObj2.length(); j++) {
                    JSONObject object = jsonObj2.getJSONObject(j);
                    XSSFRow rowObj = sheet.getRow(excelRow);
                    if (rowObj == null) {
                        rowObj = sheet.createRow(excelRow);
                    }
                    for (int k = 36; k <= 40; k++) {
                        try {
                            XSSFCell cell8 = rowObj.getCell(k);
                            if (cell8 == null) {
                                cell8 = rowObj.createCell(k);
                                cell8.setCellType(XSSFCell.CELL_TYPE_STRING);
                                if (object.get(prop.getProperty(Integer.toString(k)).toString()).toString() != null &&
                                    !object.get(prop.getProperty(Integer.toString(k)).toString())
                                           .toString()
                                           .equalsIgnoreCase(null) && !object.get(prop.getProperty(Integer.toString(k)).toString())
                                                                             .toString()
                                                                             .equalsIgnoreCase("null")) {
                                    cell8.setCellValue(object.get(prop.getProperty(Integer.toString(k)).toString())
                                                       .toString());
                                }
                            } else {
                                if (object.get(prop.getProperty(Integer.toString(k)).toString()).toString() != null &&
                                    !object.get(prop.getProperty(Integer.toString(k)).toString())
                                           .toString()
                                           .equalsIgnoreCase(null) && !object.get(prop.getProperty(Integer.toString(k)).toString())
                                                                             .toString()
                                                                             .equalsIgnoreCase("null")) {
                                    cell8.setCellValue(object.get(prop.getProperty(Integer.toString(k)).toString())
                                                       .toString());
                                }
                            }
                        } catch (JSONException e) {
                            rowObj.createCell(k).setCellValue("");

                        }
                    }
                    excelRow++;
                }
            } catch (JSONException e) {
                e.getMessage();
            }
            out = response.getOutputStream();
            wb.write(out);
        } catch (Exception e) {
            throw new ServletException("Exception in Excel  Servlet", e);
        } finally {
            if (out != null)
                out.close();
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,
                                                                                          IOException {
        processRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
                                                                                           IOException {
        processRequest(request, response);
    }

    public String getServletInfo() {
        return "ExcelCreation";
    }

}


