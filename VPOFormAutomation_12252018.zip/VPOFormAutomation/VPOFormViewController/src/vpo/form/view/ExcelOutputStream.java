package vpo.form.view;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import java.util.Properties;


import javax.ws.rs.QueryParam;

import org.json.JSONObject;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;

import javax.faces.context.FacesContext;

import javax.servlet.ServletContext;

import org.apache.myfaces.trinidad.util.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ExcelOutputStream {
    Properties prop = new Properties();

    public ExcelOutputStream() {
        super();
    }

    public static void main(String[] args) throws Exception {
        ExcelOutputStream obj = new ExcelOutputStream();

        Path path = Paths.get("D:\\Revathi\\Novartis\\VPO\\Documents\\Form Automation\\Templates\\test2.xlsx");
        Files.write(path, obj.excelOutput());
    }


    public byte[] excelOutput() {

        byte[] outputStream = null;
        Properties prop = new Properties();
        try {
            InputStream inputStream = getClass().getClassLoader().getResourceAsStream("CL.properties");

            prop.load(inputStream);

            InputStream is = this.getClass()
                                 .getClassLoader()
                                 .getResourceAsStream("META-INF/RCR.xlsx");
            XSSFWorkbook wb = new XSSFWorkbook(is);
            XSSFSheet sheet = wb.getSheetAt(0);
            // XSSFRow excelRow;
            for (int i = 6; i < 100; i++) {
                XSSFRow excelRow = sheet.getRow(i);
                System.out.println(excelRow);
                if (excelRow == null) {
                    System.out.println("i//...." + i);
                    excelRow = sheet.createRow(i);
                    System.out.println(excelRow);
                }

                try {
                    // excelRow.getCell(1).setCellValue(i + "");
                    XSSFCell cell = excelRow.getCell(1);
                    System.out.println("c.." + cell);
                    if (cell == null) {
                        cell = excelRow.createCell(1);
                        System.out.println("cell.." + cell);
                        cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                        cell.setCellValue("Apple");
                    } else {
                        cell.setCellValue(i + "");
                    }
                } catch (Exception e) {
                    // System.out.println("i/...." + i);
                    //                    excelRow.createCell(1);
                    //                    System.out.println(excelRow.createCell(1).CELL_TYPE_BLANK);
                    //
                    //                    excelRow.getCell(0).setCellValue(i + "");
                    e.printStackTrace();
                }
            }
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            try {
                wb.write(bos);
            } finally {
                bos.close();
            }
            outputStream = bos.toByteArray();
            is.close();
            Files.write(new File("D:\\test.xlsx").toPath(), outputStream);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return outputStream;
    }


}
