package vpo.form.model.pojo;

public class VendorForms {

    String studyCode;
    String country;
    int site;
    String primaryInvestigator;
    String cra;
    String vendorCategory;
    String vendor;
    String draftForms;
    int totalForms;
    int completedForms;
    int overdueForms;

    public VendorForms() {
        super();
    }

    public void setStudyCode(String studyCode) {
        this.studyCode = studyCode;
    }

    public String getStudyCode() {
        return studyCode;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCountry() {
        return country;
    }

    public void setSite(int site) {
        this.site = site;
    }

    public int getSite() {
        return site;
    }

    public void setPrimaryInvestigator(String primaryInvestigator) {
        this.primaryInvestigator = primaryInvestigator;
    }

    public String getPrimaryInvestigator() {
        return primaryInvestigator;
    }

    public void setCra(String cra) {
        this.cra = cra;
    }

    public String getCra() {
        return cra;
    }

    public void setVendorCategory(String vendorCategory) {
        this.vendorCategory = vendorCategory;
    }

    public String getVendorCategory() {
        return vendorCategory;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public String getVendor() {
        return vendor;
    }

    public void setDraftForms(String draftForms) {
        this.draftForms = draftForms;
    }

    public String getDraftForms() {
        return draftForms;
    }

    public void setTotalForms(int totalForms) {
        this.totalForms = totalForms;
    }

    public int getTotalForms() {
        return totalForms;
    }

    public void setCompletedForms(int completedForms) {
        this.completedForms = completedForms;
    }

    public int getCompletedForms() {
        return completedForms;
    }

    public void setOverdueForms(int overdueForms) {
        this.overdueForms = overdueForms;
    }

    public int getOverdueForms() {
        return overdueForms;
    }
}
