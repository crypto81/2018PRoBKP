package vpo.form.view;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.jbo.ApplicationModule;
import oracle.jbo.client.Configuration;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import vpo.form.model.AppModuleImpl;
import vpo.form.model.pojo.VendorForms;

public class ReportingVF extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String amDef = "vpo.form.model.AppModule";
    private static final String config = "AppModuleLocal";

    public ReportingVF() {
        super();
    }

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    public void destroy() {
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException,
                                                                                                   IOException {
        ApplicationModule am = null;
        OutputStream out = null;
        AppModuleImpl service = null;
        try {
            am = Configuration.createRootApplicationModule(amDef, config);
            response.setContentType("application/vnd.ms-excel");
            Date date = new Date();
            response.setHeader("Content-Disposition",
                               "attachment; filename=ReportingVendorForms" + date.toString() + ".xlsx");
            InputStream is = this.getClass()
                                 .getClassLoader()
                                 .getResourceAsStream("META-INF/RVF.xlsx");
            String fromDateVal = request.getParameter("fromDateVal");
            String toDateVal = request.getParameter("toDateVal");
            String trialVal = request.getParameter("trialVal");
            String countryVal = request.getParameter("countryVal");
            String siteVal = request.getParameter("siteVal");
            String primaryInvVal = request.getParameter("primaryInvVal");
            String craVal = request.getParameter("craVal");
            String vendorCatVal = request.getParameter("vendorCatVal");
            String vendorVal = request.getParameter("vendorVal");
            String draftFormsVal = request.getParameter("draftFormsVal");
            String totalFormsVal = request.getParameter("totalFormsVal");
            String completedFormsVal = request.getParameter("completedFormsVal");
            String overdueFormsVal = request.getParameter("overdueFormsVal");
            XSSFWorkbook wb = new XSSFWorkbook(is);
            XSSFSheet sheet = wb.getSheetAt(0);
            XSSFRow excelRow;
            XSSFCell cell;
            excelRow = sheet.getRow(1);
            if (excelRow == null) {
                excelRow = sheet.createRow(1);
            }

            cell = excelRow.getCell(1);
            if (cell == null) {
                cell = excelRow.createCell(1);
                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                cell.setCellValue(fromDateVal);
            } else {
                cell.setCellValue(fromDateVal);
            }


            cell = excelRow.getCell(3);
            if (cell == null) {
                cell = excelRow.createCell(3);
                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                cell.setCellValue(toDateVal);
            } else {
                cell.setCellValue(toDateVal);
            }


            excelRow = sheet.getRow(3);
            if (excelRow == null) {
                excelRow = sheet.createRow(3);
            }

            cell = excelRow.getCell(1);
            if (cell == null) {
                cell = excelRow.createCell(1);
                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                cell.setCellValue(date.toString());
            } else {
                cell.setCellValue(date.toString());
            }


            try {
                service = (AppModuleImpl) am;
                ArrayList<VendorForms> vendorResults =
                    service.getVendorFormReportProcedure(fromDateVal, toDateVal, trialVal, countryVal, siteVal,
                                                         primaryInvVal, craVal, vendorCatVal, vendorVal, draftFormsVal,
                                                         totalFormsVal, completedFormsVal, overdueFormsVal);

                int count = 6;
                try {
                    for (VendorForms obj : vendorResults) {

                        excelRow = sheet.getRow(count);
                        if (excelRow == null) {
                            excelRow = sheet.createRow(count);
                        }

                        try {
                            cell = excelRow.getCell(0);
                            if (cell == null) {
                                cell = excelRow.createCell(0);
                                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                                cell.setCellValue(obj.getStudyCode());
                            } else {
                                cell.setCellValue(obj.getStudyCode());
                            }
                        } catch (Exception e1) {
                            excelRow.getCell(0).setCellValue("");
                        }
                        try {
                            cell = excelRow.getCell(1);
                            if (cell == null) {
                                cell = excelRow.createCell(1);
                                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                                cell.setCellValue(obj.getCountry());
                            } else {
                                cell.setCellValue(obj.getCountry());
                            }
                        } catch (Exception e1) {
                            excelRow.getCell(1).setCellValue("");
                        }
                        try {
                            cell = excelRow.getCell(2);
                            if (cell == null) {
                                cell = excelRow.createCell(2);
                                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                                cell.setCellValue(Integer.toString(obj.getSite()));
                            } else {
                                cell.setCellValue(Integer.toString(obj.getSite()));
                            }
                        } catch (Exception e1) {
                            excelRow.getCell(2).setCellValue("");
                        }
                        try {
                            cell = excelRow.getCell(3);
                            if (cell == null) {
                                cell = excelRow.createCell(3);
                                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                                cell.setCellValue(obj.getPrimaryInvestigator());
                            } else {
                                cell.setCellValue(obj.getPrimaryInvestigator());
                            }
                        } catch (Exception e1) {
                            excelRow.getCell(3).setCellValue("");
                        }
                        try {
                            cell = excelRow.getCell(4);
                            if (cell == null) {
                                cell = excelRow.createCell(4);
                                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                                cell.setCellValue(obj.getCra());
                            } else {
                                cell.setCellValue(obj.getCra());
                            }
                        } catch (Exception e1) {
                            excelRow.getCell(4).setCellValue("");
                        }
                        try {
                            cell = excelRow.getCell(5);
                            if (cell == null) {
                                cell = excelRow.createCell(5);
                                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                                cell.setCellValue(obj.getVendorCategory());
                            } else {
                                cell.setCellValue(obj.getVendorCategory());
                            }
                        } catch (Exception e1) {
                            excelRow.getCell(5).setCellValue("");
                        }
                        try {
                            cell = excelRow.getCell(6);
                            if (cell == null) {
                                cell = excelRow.createCell(6);
                                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                                cell.setCellValue(obj.getVendor());
                            } else {
                                cell.setCellValue(obj.getVendor());
                            }
                        } catch (Exception e1) {
                            excelRow.getCell(6).setCellValue("");
                        }
                        try {
                            cell = excelRow.getCell(7);
                            if (cell == null) {
                                cell = excelRow.createCell(7);
                                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                                cell.setCellValue(obj.getDraftForms());
                            } else {
                                cell.setCellValue(obj.getDraftForms());
                            }
                        } catch (Exception e1) {
                            excelRow.getCell(7).setCellValue("");
                        }
                        try {
                            cell = excelRow.getCell(8);
                            if (cell == null) {
                                cell = excelRow.createCell(8);
                                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                                cell.setCellValue(obj.getCompletedForms());
                            } else {
                                cell.setCellValue(obj.getCompletedForms());
                            }
                        } catch (Exception e1) {
                            excelRow.getCell(8).setCellValue("");
                        }
                        try {
                            cell = excelRow.getCell(9);
                            if (cell == null) {
                                cell = excelRow.createCell(9);
                                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                                cell.setCellValue(obj.getOverdueForms());
                            } else {
                                cell.setCellValue(obj.getOverdueForms());
                            }
                        } catch (Exception e1) {
                            excelRow.getCell(9).setCellValue("");
                        }

                        try {
                            cell = excelRow.getCell(10);
                            if (cell == null) {
                                cell = excelRow.createCell(10);
                                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                                cell.setCellValue(obj.getTotalForms());
                            } else {
                                cell.setCellValue(obj.getTotalForms());
                            }
                        } catch (Exception e1) {
                            excelRow.getCell(10).setCellValue("");
                        }
                        count++;
                    }
                } catch (Exception e) {
                    throw new ServletException("Not able to write to Excel", e);
                }


            } catch (Exception e) {
                throw new ServletException("VO not found", e);
            }
            out = response.getOutputStream();
            wb.write(out);
        } catch (Exception e) {
            throw new ServletException("Exception occurred", e);
        } finally {
            if (am != null)
                Configuration.releaseRootApplicationModule(am, true);
            if (out != null)
                out.close();
            if (service != null)
                service.remove();
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,
                                                                                          IOException {
        processRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
                                                                                           IOException {
        processRequest(request, response);
    }

    public String getServletInfo() {
        return "ExcelCreation";
    }


}
