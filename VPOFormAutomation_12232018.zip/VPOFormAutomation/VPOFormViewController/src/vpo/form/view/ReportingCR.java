package vpo.form.view;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.jbo.ApplicationModule;
import oracle.jbo.Row;
import oracle.jbo.ViewObject;
import oracle.jbo.client.Configuration;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReportingCR extends HttpServlet {


    private static final long serialVersionUID = 1L;
    private static final String amDef = "vpo.form.model.AppModule";
    private static final String config = "AppModuleLocal";

    public ReportingCR() {
        super();
    }

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    public void destroy() {
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException,
                                                                                                   IOException {
        ApplicationModule am = null;
        OutputStream out = null;
        try {
            am = Configuration.createRootApplicationModule(amDef, config);

            response.setContentType("application/vnd.ms-excel");
            Date date = new Date();
            response.setHeader("Content-Disposition",
                               "attachment; filename=ReportingCountryRepository" + date.toString() + ".xlsx");
            InputStream is = this.getClass()
                                 .getClassLoader()
                                 .getResourceAsStream("META-INF/RCR.xlsx");
            XSSFWorkbook wb = new XSSFWorkbook(is);
            XSSFSheet HAECSheet = wb.getSheetAt(0);
            XSSFSheet RISSheet = wb.getSheetAt(1);
            XSSFRow excelRow;
            excelRow = HAECSheet.getRow(1);
            if (excelRow == null) {
                excelRow = HAECSheet.createRow(1);
            }
            try {
                XSSFCell cell = excelRow.getCell(1);
                if (cell == null) {
                    cell = excelRow.createCell(1);
                    cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                    cell.setCellValue(date.toString());
                } else {
                    cell.setCellValue(date.toString());
                }
            } catch (Exception e) {
                excelRow.getCell(1).setCellValue("");
            }
            excelRow = RISSheet.getRow(1);
            if (excelRow == null) {
                excelRow = RISSheet.createRow(1);
            }
            try {
                XSSFCell cell = excelRow.getCell(1);
                if (cell == null) {
                    cell = excelRow.createCell(1);
                    cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                    cell.setCellValue(date.toString());
                } else {
                    cell.setCellValue(date.toString());
                }
            } catch (Exception e) {
                excelRow.getCell(1).setCellValue("");
            }
            String countryId = request.getParameter("countryId");
            String phaseName = request.getParameter("phaseName");
            String questionId = request.getParameter("questionId");
            String regionId = request.getParameter("regionId");
            String vendorCategoryId = request.getParameter("vendorCategoryId");
            try {
                ViewObject vo = am.findViewObject("ReportingCR1");
                vo.setNamedWhereClauseParam("country_id", countryId);
                vo.setNamedWhereClauseParam("p_phase_name", phaseName);
                vo.setNamedWhereClauseParam("question_id", questionId);
                vo.setNamedWhereClauseParam("region_id", regionId);
                vo.setNamedWhereClauseParam("vendor_category_id", vendorCategoryId);
                vo.executeQuery();
                int HAECCount = 3;
                int RISCount = 3;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        if (row.getAttribute("PhaseName")
                               .toString()
                               .equalsIgnoreCase("RIS")) {
                            RISCount++;
                            excelRow = RISSheet.getRow(RISCount);
                            if (excelRow == null) {
                                excelRow = RISSheet.createRow(RISCount);
                            }
                        } else {
                            HAECCount++;
                            excelRow = HAECSheet.getRow(HAECCount);
                            if (excelRow == null) {
                                excelRow = HAECSheet.createRow(HAECCount);
                            }
                        }

                        try {
                            XSSFCell cell = excelRow.getCell(0);
                            if (cell == null) {
                                cell = excelRow.createCell(0);
                                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                                cell.setCellValue(row.getAttribute("CountryName").toString());
                            } else {
                                cell.setCellValue(row.getAttribute("CountryName").toString());
                            }
                        } catch (Exception e) {
                            excelRow.getCell(0).setCellValue("");

                        }

                        try {
                            XSSFCell cell = excelRow.getCell(1);
                            if (cell == null) {
                                cell = excelRow.createCell(1);
                                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                                cell.setCellValue(row.getAttribute("QuestionDetails").toString());
                            } else {
                                cell.setCellValue(row.getAttribute("QuestionDetails").toString());
                            }
                        } catch (Exception e1) {
                            excelRow.getCell(1).setCellValue("");

                        }

                        try {
                            XSSFCell cell = excelRow.getCell(2);
                            if (cell == null) {
                                cell = excelRow.createCell(2);
                                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                                cell.setCellValue(row.getAttribute("VcCentralLab").toString());
                            } else {
                                cell.setCellValue(row.getAttribute("VcCentralLab").toString());
                            }
                        } catch (Exception e1) {
                            excelRow.getCell(2).setCellValue("");
                        }

                        try {
                            XSSFCell cell = excelRow.getCell(3);
                            if (cell == null) {
                                cell = excelRow.createCell(3);
                                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                                cell.setCellValue(row.getAttribute("VcIrt").toString());
                            } else {
                                cell.setCellValue(row.getAttribute("VcIrt").toString());
                            }

                        } catch (Exception e1) {
                            excelRow.getCell(3).setCellValue("");
                        }


                        try {
                            XSSFCell cell = excelRow.getCell(4);
                            if (cell == null) {
                                cell = excelRow.createCell(4);
                                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                                cell.setCellValue(row.getAttribute("VcEcg").toString());
                            } else {
                                cell.setCellValue(row.getAttribute("VcEcg").toString());
                            }

                        } catch (Exception e1) {
                            excelRow.getCell(4).setCellValue("");
                        }


                        try {
                            XSSFCell cell = excelRow.getCell(5);
                            if (cell == null) {
                                cell = excelRow.createCell(5);
                                cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                                cell.setCellValue(row.getAttribute("Comments").toString());
                            } else {
                                cell.setCellValue(row.getAttribute("Comments").toString());
                            }

                        } catch (Exception e1) {
                            excelRow.getCell(5).setCellValue("");
                        }

                    } catch (Exception e) {
                        throw new ServletException("Not able to write to Excel", e);
                    }
                }
            } catch (Exception e) {
                throw new ServletException("VO not found", e);
            }
            out = response.getOutputStream();
            wb.write(out);

        } catch (Exception e) {
            throw new ServletException("Exception occurred", e);
        } finally {
            if (am != null)
                Configuration.releaseRootApplicationModule(am, true);
            if (out != null)
                out.close();
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,
                                                                                          IOException {
        processRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
                                                                                           IOException {
        processRequest(request, response);
    }

    public String getServletInfo() {
        return "ExcelCreation";
    }


}
