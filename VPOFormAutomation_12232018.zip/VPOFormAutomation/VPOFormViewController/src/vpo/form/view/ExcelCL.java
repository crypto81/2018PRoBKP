package vpo.form.view;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import java.util.Date;
import java.util.Properties;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ExcelCL extends HttpServlet {

    private static final long serialVersionUID = 1L;
    Properties prop = new Properties();

    public ExcelCL() {
        super();
    }

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    public void destroy() {
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException,
                                                                                                   IOException {
        OutputStream out = null;
        try {
            InputStream inputStream = getClass().getClassLoader().getResourceAsStream("CL.properties");
            prop.load(inputStream);
            int excelRow = Integer.parseInt(prop.getProperty("ROWNUM").toString());
            String inputJSON = request.getParameter("inputJson");
            JSONObject jsonObj = new JSONObject(inputJSON);
            Date date = new Date();
            response.setHeader("Content-Disposition", "attachment; filename=CentralLab" + date.toString() + ".xlsx");
            InputStream is = this.getClass()
                                 .getClassLoader()
                                 .getResourceAsStream("META-INF/CL.xlsx");
            XSSFWorkbook wb = new XSSFWorkbook(is);
            XSSFSheet sheet = wb.getSheetAt(Integer.parseInt(prop.getProperty("SHEETNUM").toString()));
            XSSFRow row1 = sheet.getRow(6);
            if (row1 == null) {
                row1 = sheet.createRow(6);
            }
            try {
                XSSFCell cell = row1.getCell(1);
                if (cell == null) {
                    cell = row1.createCell(1);
                    cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                    cell.setCellValue(jsonObj.get("CLSponsorName").toString());
                } else {
                    cell.setCellValue(jsonObj.get("CLSponsorName").toString());
                }

            } catch (JSONException e) {
                row1.getCell(1).setCellValue("");
            }
            XSSFRow row2 = sheet.getRow(7);
            if (row2 == null) {
                row2 = sheet.createRow(7);
            }
            try {
                XSSFCell cell = row2.getCell(1);
                if (cell == null) {
                    cell = row2.createCell(1);
                    cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                    cell.setCellValue(jsonObj.get("CLTrialCode").toString());
                } else {
                    cell.setCellValue(jsonObj.get("CLTrialCode").toString());
                }
            } catch (JSONException e) {
                row2.getCell(1).setCellValue("");
            }

            XSSFRow row3 = sheet.getRow(8);
            if (row3 == null) {
                row3 = sheet.createRow(8);
            }
            try {
                XSSFCell cell = row3.getCell(1);
                if (cell == null) {
                    cell = row3.createCell(1);
                    cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                    cell.setCellValue(jsonObj.get("CLSiteId").toString());
                } else {
                    cell.setCellValue(jsonObj.get("CLSiteId").toString());
                }
            } catch (JSONException e) {
                row3.getCell(1).setCellValue("");
            }

            XSSFRow row5 = sheet.getRow(11);
            if (row5 == null) {
                row5 = sheet.createRow(11);
            }
            try {
                XSSFCell cell = row5.getCell(1);
                if (cell == null) {
                    cell = row5.createCell(1);
                    cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                    cell.setCellValue(jsonObj.get("completedBy").toString());
                } else {
                    cell.setCellValue(jsonObj.get("completedBy").toString());
                }
            } catch (JSONException e) {
                row5.getCell(1).setCellValue("");
            }

            XSSFRow row4 = sheet.getRow(12);
            if (row4 == null) {
                row4 = sheet.createRow(12);
            }
            try {
                XSSFCell cell = row4.getCell(1);
                if (cell == null) {
                    cell = row4.createCell(1);
                    cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                    cell.setCellValue(jsonObj.get("completedDate").toString());
                } else {
                    cell.setCellValue(jsonObj.get("completedDate").toString());
                }
            } catch (JSONException e) {
                row4.getCell(1).setCellValue("");
            }


            XSSFRow row = sheet.getRow(excelRow);
            if (row == null) {
                row = sheet.createRow(excelRow);
            }
            for (int i = 1; i <= 35; i++) {
                try {
                    if (i == 35) {
                        String flag1 = "";
                        String flag2 = "";
                        String flag3 = "";
                        try {
                            flag1 = jsonObj.get(prop.getProperty("350").toString()).toString();
                        } catch (JSONException e) {
                            flag1 = "";
                        }
                        try {
                            flag2 = jsonObj.get(prop.getProperty("351").toString()).toString();
                        } catch (JSONException e) {
                            flag2 = "";
                        }
                        try {
                            flag3 = jsonObj.get(prop.getProperty("352").toString()).toString();
                        } catch (JSONException e) {
                            flag3 = "";

                        }
                        XSSFCell cell = row.getCell(i);
                        if (cell == null) {
                            cell = row.createCell(i);
                            cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                            cell.setCellValue(flag1 + flag2 + flag3);
                        } else {
                            cell.setCellValue(flag1 + flag2 + flag3);
                        }
                    } else {
                        XSSFCell cell = row.getCell(i);
                        if (cell == null) {
                            cell = row.createCell(i);
                            cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                            cell.setCellValue(jsonObj.get(prop.getProperty(i + "").toString()).toString());
                        } else {
                            cell.setCellValue(jsonObj.get(prop.getProperty(i + "").toString()).toString());
                        }
                    }
                } catch (JSONException e) {
                    row.getCell(i).setCellValue("");
                }
            }
            JSONArray jsonObj2 = jsonObj.getJSONArray(prop.getProperty("ReportShipping").toString());
            for (int j = 0; j < jsonObj2.length(); j++) {
                JSONObject object = jsonObj2.getJSONObject(j);
                XSSFRow rowObj = sheet.getRow(excelRow);
                if (rowObj == null) {
                    rowObj = sheet.createRow(excelRow);
                }
                for (int k = 36; k <= 40; k++) {
                    try {
                        XSSFCell cell = rowObj.getCell(k);
                        if (cell == null) {
                            cell = rowObj.createCell(k);
                            cell.setCellType(XSSFCell.CELL_TYPE_STRING);
                            cell.setCellValue(object.get(prop.getProperty(Integer.toString(k)).toString()).toString());
                        } else {
                            cell.setCellValue(object.get(prop.getProperty(Integer.toString(k)).toString()).toString());
                        }
                    } catch (JSONException e) {
                        rowObj.createCell(k).setCellValue("");

                    }
                }
                excelRow++;
            }
            out = response.getOutputStream();
            wb.write(out);
        } catch (Exception e) {
            throw new ServletException("Exception in Excel  Servlet", e);
        } finally {
            if (out != null)
                out.close();
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,
                                                                                          IOException {
        processRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
                                                                                           IOException {
        processRequest(request, response);
    }

    public String getServletInfo() {
        return "ExcelCreation";
    }


}


