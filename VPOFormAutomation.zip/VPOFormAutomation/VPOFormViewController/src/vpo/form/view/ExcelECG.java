package vpo.form.view;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.Properties;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ExcelECG extends HttpServlet {
    private static final long serialVersionUID = 1L;
    Properties prop = new Properties();

    public ExcelECG() {
        super();
    }


    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    public void destroy() {
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException,
                                                                                                   IOException {
        OutputStream out = null;
        try {
            InputStream inputStream = getClass().getClassLoader().getResourceAsStream("ECG.properties");
            prop.load(inputStream);
            int excelRow = Integer.parseInt(prop.getProperty("ROWNUM").toString());
            String inputJSON = request.getParameter("inputJson");
            JSONObject jsonObj = new JSONObject(inputJSON);
            String trialId = "";
            try {
                if (jsonObj.get("ECGTrialCode").toString() != null && !jsonObj.get("ECGTrialCode")
                                                                              .toString()
                                                                              .equalsIgnoreCase(null) &&
                    !jsonObj.get("ECGTrialCode")
                                                                                                                 .toString()
                                                                                                                 .equalsIgnoreCase("null")) {
                    trialId = jsonObj.get("ECGTrialCode").toString();
                }
            } catch (JSONException e) {
                e.getMessage();
            }
            String siteId = "";
            try {
                if (jsonObj.get("ECGSiteId").toString() != null && !jsonObj.get("ECGSiteId")
                                                                           .toString()
                                                                           .equalsIgnoreCase(null) &&
                    !jsonObj.get("ECGSiteId")
                                                                                                              .toString()
                                                                                                              .equalsIgnoreCase("null")) {
                    siteId = jsonObj.get("ECGSiteId").toString();
                }
            } catch (JSONException e) {
                e.getMessage();
            }
            String vendorName = "";
            try {
                if (jsonObj.get("vendorName").toString() != null && !jsonObj.get("vendorName")
                                                                            .toString()
                                                                            .equalsIgnoreCase(null) &&
                    !jsonObj.get("vendorName")
                                                                                                               .toString()
                                                                                                               .equalsIgnoreCase("null")) {
                    vendorName = jsonObj.get("vendorName").toString();
                }
            } catch (JSONException e) {
                e.getMessage();
            }
            SimpleDateFormat formatter = new SimpleDateFormat("ddMMMyy");
            String date = formatter.format(new Date());
            String fileName = "";
            if (trialId != "" && !trialId.equalsIgnoreCase("") && !trialId.equalsIgnoreCase(null) &&
                !trialId.equalsIgnoreCase("null")) {
                fileName = fileName + trialId + "_";
            }
            if (siteId != "" && !siteId.equalsIgnoreCase("") && !siteId.equalsIgnoreCase(null) &&
                !siteId.equalsIgnoreCase("null")) {
                fileName = fileName + siteId + "_";
            }

            if (vendorName != "" && !vendorName.equalsIgnoreCase("") && !vendorName.equalsIgnoreCase(null) &&
                !vendorName.equalsIgnoreCase("null")) {
                fileName = fileName + vendorName + "_";
            }
            fileName = fileName + date + "V1.0.xlsx";
            response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
            InputStream is = this.getClass()
                                 .getClassLoader()
                                 .getResourceAsStream("META-INF/ECG.xlsx");
            XSSFWorkbook wb = new XSSFWorkbook(is);
            XSSFSheet sheet = wb.getSheetAt(Integer.parseInt(prop.getProperty("SHEETNUM").toString()));
            XSSFRow row1 = sheet.getRow(6);
            if (row1 == null) {
                row1 = sheet.createRow(6);
            }

            XSSFCell cell = row1.getCell(1);
            if (cell == null) {
                cell = row1.createCell(1);
                cell.setCellType(XSSFCell.CELL_TYPE_STRING);

                cell.setCellValue(vendorName);
            } else {
                cell.setCellValue(vendorName);
            }

            XSSFRow row2 = sheet.getRow(7);
            if (row2 == null) {
                row2 = sheet.createRow(7);
            }

            XSSFCell cell1 = row2.getCell(1);
            if (cell1 == null) {
                cell1 = row2.createCell(1);
                cell1.setCellType(XSSFCell.CELL_TYPE_STRING);
                cell1.setCellValue(trialId);
            } else {
                cell1.setCellValue(trialId);
            }

            XSSFRow row3 = sheet.getRow(8);
            if (row3 == null) {
                row3 = sheet.createRow(8);
            }

            XSSFCell cell3 = row3.getCell(1);
            if (cell3 == null) {
                cell3 = row3.createCell(1);
                cell3.setCellType(XSSFCell.CELL_TYPE_STRING);
                cell3.setCellValue(siteId);
            } else {
                cell3.setCellValue(siteId);
            }

            XSSFRow row5 = sheet.getRow(10);
            if (row5 == null) {
                row5 = sheet.createRow(10);
            }
            try {
                XSSFCell cell4 = row5.getCell(1);
                if (cell4 == null) {
                    cell4 = row5.createCell(1);
                    cell4.setCellType(XSSFCell.CELL_TYPE_STRING);
                    if (jsonObj.get("completedBy").toString() != null && !jsonObj.get("completedBy")
                                                                                 .toString()
                                                                                 .equalsIgnoreCase(null) &&
                        !jsonObj.get("completedBy")
                                                                                                                    .toString()
                                                                                                                    .equalsIgnoreCase("null")) {
                        cell4.setCellValue(jsonObj.get("completedBy").toString());
                    }
                } else {
                    if (jsonObj.get("completedBy").toString() != null && !jsonObj.get("completedBy")
                                                                                 .toString()
                                                                                 .equalsIgnoreCase(null) &&
                        !jsonObj.get("completedBy")
                                                                                                                    .toString()
                                                                                                                    .equalsIgnoreCase("null")) {
                        cell4.setCellValue(jsonObj.get("completedBy").toString());
                    }
                }
            } catch (JSONException e) {
                e.getMessage();

            }
            XSSFRow row4 = sheet.getRow(11);
            if (row4 == null) {
                row4 = sheet.createRow(11);
            }

            XSSFCell cell5 = row4.getCell(1);
            try {
                if (cell5 == null) {
                    cell5 = row4.createCell(1);
                    cell5.setCellType(XSSFCell.CELL_TYPE_STRING);
                    if (jsonObj.get("completedDate").toString() != null && !jsonObj.get("completedDate")
                                                                                   .toString()
                                                                                   .equalsIgnoreCase(null) &&
                        !jsonObj.get("completedDate")
                                                                                                                      .toString()
                                                                                                                      .equalsIgnoreCase("null")) {
                        cell5.setCellValue(jsonObj.get("completedDate").toString());
                    }
                } else {
                    if (jsonObj.get("completedDate").toString() != null && !jsonObj.get("completedDate")
                                                                                   .toString()
                                                                                   .equalsIgnoreCase(null) &&
                        !jsonObj.get("completedDate")
                                                                                                                      .toString()
                                                                                                                      .equalsIgnoreCase("null")) {
                        cell5.setCellValue(jsonObj.get("completedDate").toString());
                    }
                }
            } catch (JSONException e) {
                e.getMessage();

            }
            XSSFRow row = sheet.getRow(excelRow);
            if (row == null) {
                row = sheet.createRow(excelRow);
            }
            for (int i = 1; i <= 25; i++) {

                try {

                    XSSFCell cell6 = row.getCell(i);
                    if (cell6 == null) {
                        cell6 = row.createCell(i);
                        cell6.setCellType(XSSFCell.CELL_TYPE_STRING);

                        if (jsonObj.get(prop.getProperty(i + "").toString()).toString() != null &&
                            !jsonObj.get(prop.getProperty(i + "").toString())
                                    .toString()
                                    .equalsIgnoreCase(null) && !jsonObj.get(prop.getProperty(i + "").toString())
                                                                       .toString()
                                                                       .equalsIgnoreCase("null")) {
                            cell6.setCellValue(jsonObj.get(prop.getProperty(i + "").toString()).toString());
                        }
                    } else {
                        if (jsonObj.get(prop.getProperty(i + "").toString()).toString() != null &&
                            !jsonObj.get(prop.getProperty(i + "").toString())
                                    .toString()
                                    .equalsIgnoreCase(null) && !jsonObj.get(prop.getProperty(i + "").toString())
                                                                       .toString()
                                                                       .equalsIgnoreCase("null")) {
                            cell6.setCellValue(jsonObj.get(prop.getProperty(i + "").toString()).toString());
                        }
                    }
                } catch (JSONException e) {
                    e.getMessage();
                }

            }
            out = response.getOutputStream();
            wb.write(out);
        } catch (Exception e) {
            throw new ServletException("Exception in Excel  Servlet", e);
        } finally {
            if (out != null)
                out.close();
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,
                                                                                          IOException {
        processRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
                                                                                           IOException {
        processRequest(request, response);
    }

    public String getServletInfo() {
        return "ExcelCreation";
    }

}
