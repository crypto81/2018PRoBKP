package vpo.form.view;

public class SaveExcel {

    ExcelCL obj = new ExcelCL();
    public SaveExcel() {
        super();
    }
}
